<?php
$username='root';
$password='';

try {
	$conn = new PDO('mysql:host=localhost;dbname=fiximg', $username, $password
			,	array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
	);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
	echo 'ERROR: ' . $e->getMessage();
}


$data = $conn->query('SELECT * FROM pic_Images limit 10' );

$return_arr=array();
foreach($data as $row) {
	//print_r($row);
	//echo '{"members":'.json_encode($arr).'}';
	//$json = '{"sample":'.json_encode($arr).'}';

	$row_array['id'] = $row['id'];
	$row_array['resim_ad'] = $row['image_name'];
	$row_array['resm_bilgi'] = $row['picture_path'];
	//	$row_array['col1'] = $row['col1'];
	//$row_array['col2'] = $row['col2'];

	array_push($return_arr,$row_array);
}
$json_data=json_encode($return_arr);


function ufirst($val) {
	return ucfirst(strtolower($val));
}

//baş harfleri buyuk yapmak için bi çözüm bulmam lazım
//data ne tipde gelecek ext js de farklı da koyabilsin adam
//2 -- soru işaretli olan terrnatory için bişey data için bu kontrol ok

/**
 *@author Selman TUNÇ <selman.tunc@yceo.com.tr>
 *@example echo	sql2json ('SELECT * FROM  `musteri` ');
 *@param string sql query
* @return string json returned
 */

function sql2json ($sql) {
	try {
		$conn = new PDO('mysql:host=localhost;dbname=firmam', 'root','',array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch(PDOException $e) {
		echo 'ERROR: ' . $e->getMessage();
	}
	
	$stmt = $conn->prepare($sql);
	$stmt->execute();
	$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$sql_count=$stmt->rowCount();
	if ( $sql_count ) {
		$returned='{total: '.$sql_count.',
				data: '.json_encode($result).'}';
	}
	else
	{
		$returned='{total: 0, data:[ ]}';
	}

	return $returned;


}




