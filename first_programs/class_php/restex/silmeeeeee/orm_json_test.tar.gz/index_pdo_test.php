<?php
class PRETTY_JSON{
	 
	function beautify_json($json) {
		$tab = "  ";
		$new_json = "";
		$indent_level = 0;
		$in_string = false;
		 
		$json_obj = json_decode($json);
		 
		if($json_obj === false)
			return false;
		 
		$json = json_encode($json_obj);
		$len = strlen($json);
		 
		for($c = 0; $c < $len; $c++)
		{
		$char = $json[$c];
		switch($char)
		{
		case '{':
		case '[':
		if(!$in_string)
		{
			$new_json .= $char . "\n" . str_repeat($tab, $indent_level+1);
			$indent_level++;
		}
			else
				{
					$new_json .= $char;
		}
							break;
							case '}':
							case ']':
							if(!$in_string)
							{
							$indent_level--;
							$new_json .= "\n" . str_repeat($tab, $indent_level) . $char;
							}
							else
							{
			$new_json .= $char;
		}
		break;
			case ',':
			if(!$in_string)
			{
			$new_json .= ",\n" . str_repeat($tab, $indent_level);
			}
				else
				{
				$new_json .= $char;
			}
			break;
			case ':':
			if(!$in_string)
			{
			$new_json .= ": ";
			}
			else
			{
			$new_json .= $char;
		}
		break;
		case '"':
				if($c > 0 && $json[$c-1] != '\\')
				{
				$in_string = !$in_string;
		}
		default:
			$new_json .= $char;
					break;
		}
		}
		 
		return $new_json;
		}
		}
		
		

$name = 'Joe'; # user-supplied data
$username='root';
$password='';
$return_arr=array();
try {
	$conn = new PDO('mysql:host=localhost;dbname=fiximg', $username, $password
		,	array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
	);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	
	} catch(PDOException $e) {
		echo 'ERROR: ' . $e->getMessage();
	}
	
//function function_name($sql,$limit=NULL) {
	$data = $conn->query('SELECT * FROM pic_Images limit 10' );
	

	//	$data = $conn->query('SELECT * FROM pic_Images WHERE name = ' . $conn->quote($name));
	foreach($data as $row) {
		//print_r($row);
	//echo '{"members":'.json_encode($arr).'}';
	//$json = '{"sample":'.json_encode($arr).'}'; 
	
		$row_array['id'] = $row['id'];
		$row_array['resim_ad'] = $row['image_name'];
		$row_array['resm_bilgi'] = $row['picture_path'];
		//	$row_array['col1'] = $row['col1'];
		//$row_array['col2'] = $row['col2'];
	
		array_push($return_arr,$row_array);
	}
	 $json_data=json_encode($return_arr);

	
	
	$stmt = $conn->prepare('SELECT * FROM pic_Images limit 10');
	$stmt->execute();

	$result = $stmt->fetchAll();
	if ( count($result) ) {
		foreach($result as $row) {
			print_r($row);
		}}
	
		echo $stmt->rowCount();//toplam kaç değer
	

	$data = $conn->query('SHOW COLUMNS FROM pic_Images ' );
	foreach($data as $row) {
		 $row['Field'];
	}
	
	$sth=$conn->prepare("SHOW COLUMNS FROM pic_Images ");
	$sth->execute();
$sth->fetchColumn();


//json_decode($json_data);

//$json = new PRETTY_JSON();

//print $json->beautify_json($json_data);


//fetch both orneği
//PDO::FETCH_BOTH (öntanımlı): Hem sütun isimlerine 
//hem de sütun numaralarına göre indislenmiş bir dizi döner. İlk sütunun indisi 0'dır.

$sql="select * from student";

$stmt=$dbh->query($sql);

$result=$stmt->fetch(PDO::FETCH_BOTH);

echo "<table border=1>";

foreach($result as $key=>$val)

{

	echo "<tr><td>".$key."</td>";

	echo "<td>".$val."</td></tr>";

}

