<?php

class RestClient {
  /**
   * Api çağrıların yapmamızı sağlayacak istemcimiz
   * REST çağrıları HTTP protokolü ile yapılacağından
   * curl e ihityaç duyuyoruz
   *
   * @var resource
   */
  protected $client;
  /**
   * Api çağrılarının yapılacağı URL
   *
   * @var string
   */
  protected $url;

  public function __construct($url){
    $this->client = curl_init();
    $this->url = $url;
    curl_setopt($this->client, CURLOPT_RETURNTRANSFER ,1);
  }
  /**
   * Rest sunucumuza istek yapmamızı ve sonucu
   * ekrana yazdırmamızı sağlar.
   *
   * @return void
   */
  public function call($function,$params=null){
    curl_setopt($this->client,CURLOPT_URL,$this->url.'/'.$function);
     curl_setopt($this->client, CURLOPT_POST, 0);
    if(is_array($params)){
      curl_setopt($this->client, CURLOPT_POST, 1);
      curl_setopt($this->client,CURLOPT_POSTFIELDS,$params);
    }
    echo curl_exec($this->client);
  }
}

$client = new RestClient('api.local');
$client->call('date',array('params'=>json_encode(array('d-m-Y H:i:s'))));
$client->call('phpinfo');
