<?php
class RestServer {
  /**
   * Döndürülecek yanıt tipini belirliyoruz
   *
   * @var string $responseType
   */
  protected $responseType;
  /**
   * Classımızın construct metoduna döndürmek istediğimiz
   * farklı bir yanıt tipi varsa bunu verebiliyoruz
   *
   */
  public function __construct($responseType = "text/json"){
    $this->responseType = $responseType;
  }
  /**
   * Sunucumuzun başlatılmasını sağlar
   *
   * @return void
   */
  public function run(){
    // döndürmek istediğimiz yanıt tipini belirtiyoruz.
    header('Content-type: '.$this->responseType);
    // yaptığımız hataları başkaları görsün istemiyoruz :)
    set_error_handler(array($this,'errorHandler'));
    // gelen komutu algılayıp cevabımızı ekrana yazdırıyoruz
    echo $this->response();
  }
  /**
   * Tüm işi burası yapıyor, bizden ne istendiğini
   * anlayarak bir cevap vermemiz gerekiyor.
   *
   * @return mixed
   */  
  public function response(){
    $request   = substr($_SERVER['REQUEST_URI'],1);
    $request   = explode('/',$request);
    $function  = array_shift($request);

    if(isset($_POST['params'])) {
      $_POST['params'] = json_decode($_POST['params']);
      return call_user_func_array($function,$_POST['params']);
    }else {
      return call_user_func($function);
    }
  }
  /**
   * Hata yakalayıcımız, sistemdeki hataları göstermeyip standart
   * bir mesaj döndürüyoruz. Bu sistemi geliştirerek hata raporlaması vb şeyler de
   * yapılabilir. Fantaziye gerek yok, basit bir örnek sadece :)
   */
  public function errorHandler ($errno, $errstr, $errfile, $errline) {
    echo 'Hatalı veya eksik istek';
    exit;
  }
}
$server = new RestServer('text/html');
$server->run();
