<?php

Autoloader::directories(array(
	Bundle::path('bob').'classes'
));