<?php 

return array(

	'previous' => '&laquo; Vorige',
	'next'     => 'Volgende &raquo;',

);