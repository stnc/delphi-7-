PHP Namespaces in 120 Seconds Tutorial
======================================

Hiya! This repository houses the script and other items related to
the short KnpUniversity screencast
[PHP Namespaces in 120 Seconds Tutorial](http://knpuniversity.com/screencast/php-namespaces-in-120-seconds).
