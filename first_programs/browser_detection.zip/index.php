<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-11056568-7']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<?php 
require_once 'stnc_userAgent.php';//class
//echo $_SERVER [ "HTTP_USER_AGENT" ];
$detector =new detector($_SERVER [ "HTTP_USER_AGENT" ] );//new object creator		

 
echo '<font color="red">Browser Detector</font> <br>'; 
echo $detector-> browser ; 
echo '<br>';
echo $detector->mobile_browser; 
echo '<br>';
echo $detector-> vip_bot;  
echo '<br>';
echo $detector->robot; 
echo '<br>';
echo $detector-> operating_system;
echo '<br>';
echo $detector-> browser_lang;
echo '<br>';
echo $detector->basic_browser;
echo '<br>';


if ($detector->mobile_browser=="Apple iPhone")
echo 'Apple iPhone user<br>';
//header("Location: http://touch.facebook.com"); //example

echo '<font color="red">****ACTIONS************ </font> <br>'; 
 if ($detector->is_mobile)
 echo 'this is mobil browser --> '.$detector->mobile_browser.'<br>'; 
  if ($detector->is_browser)
   echo 'browser versiyon --> '.$detector-> browser.'<br>' ; 
  if ($detector->is_vip_bot)
   echo 'vip boot is --> '.$detector-> vip_bot.'<br>'; 
  if ($detector->is_robot)
   echo 'Boot is -->'.$detector->robot.'<br>';  
?>
<p><p>

<p>
<a href="http://www.selmantunc.com/?file_id=102">Download Link</a><br>

Web site :<a href="http://www.selmantunc.com?ref=doc" target="_blank">www.selmantunc.com</a><br>
Mail :<a href="mailto:stncweb@gmail.com">stncweb@gmail.com</a><br>
Twitter:<a href="http://twitter.com/stunc" target="_blank">http://twitter.com/stunc  </a><br>
Friendfeed :<a href="http://friendfeed.com/stnc" target="_blank">http://friendfeed.com/stnc </a>  <br>    
Facebook: <a href="http://www.facebook.com/s.stnc" target="_blank">http://www.facebook.com/s.stnc</a><br>

<p><p>
-------------Mobil Browser Demonstration --Opera Mini----------------
<br>
<a href="http://www.opera.com/mobile/demo/"> http://www.opera.com/mobile/demo/</a> <br>

-------------Firefox Extension Demo-----Apple iphone and other-----------
<br>
<a href="http://chrispederick.com/work/user-agent-switcher/"> User Agent Switcher</a> <br>
The User Agent Switcher extension adds a menu and a toolbar button to switch the user agent of the browser. 
It is designed for Firefox, Flock, Seamonkey  and Songbird, and will run on any platform that these browsers 
support including Windows, Mac OS  X and Linux. 
