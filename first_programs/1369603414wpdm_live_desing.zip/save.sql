


DROP TABLE IF EXISTS `pref`;
CREATE TABLE `pref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bg_color` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `font_type_bold` tinyint(3) DEFAULT NULL,
  `font_type_italic` tinyint(3) DEFAULT NULL,
  `font_size` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `font_family` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `link_color` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `link_hover_color` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `font_color` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Dumping data for table pref
#
LOCK TABLES `pref` WRITE;
/*!40000 ALTER TABLE `pref` DISABLE KEYS */;

INSERT INTO `pref` VALUES (1,'090f24',0,0,'15','Verdana, Geneva, sans-serif','ba55ba','090f24','851985');

