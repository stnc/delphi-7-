<?php 
header("Content-Type: text/html; charset=utf-8");


 function security_html ($string) {
if(get_magic_quotes_gpc()) // magic_quotes_gpc a��ksa
{
$string = stripslashes($string); // bu fonksiyon escape edilmi� zararl� karakterleri d�zeltmemizi sa�l�yor
}
elseif(!get_magic_quotes_gpc()) // magic_quotes_gpc kapal� ise
{
$string = addslashes($string); // bu zararl� karakterleri escape etmemize yar�yor..
}
$string = @mysql_real_escape_string($string); // bu son �nlem olarak $string de�i�keni i�indeki her bi zararl� �eyi yok ediyor :D
return $string; // son olaraktaa temizlenmi� ve pisliklerinden ayr�lm�� bir $string de�i�keni elde ediyoruz...

}


 date_default_timezone_set('Europe/Istanbul');
include_once ('../lib/class.ez_sql_core.php');
include_once ('../lib/class.ez_sql_mysql.php');
require_once ('../connect.php');


    
 $id = intval($_POST['id']);
$body_background_color = security_html($_POST['body_background_color']);
$body_font_color = security_html($_POST['body_font_color']);
$body_font_font_size = security_html($_POST['body_font_font_size']);   
$body_link_color= security_html($_POST['body_link_color']);
 $body_link_hover_color= security_html($_POST['body_link_hover_color']);
 $font_fontfamily = security_html($_POST['font_fontfamily']); 
 // $body_font_fonttype_Bold = security_html($_POST['body_font_fonttype_Bold']); 
  // $body_font_fonttype_Italic = security_html($_POST['body_font_fonttype_Italic']); 
  	
		if (isset($_POST['body_font_fonttype_Bold'])){ $body_font_fonttype_Bold = 1; } else {  $body_font_fonttype_Bold = 0;}
		
	 if (isset($_POST['body_font_fonttype_Italic'])){ $body_font_fonttype_Italic = 1;} else { $body_font_fonttype_Italic = 0;}
 
	  if (isset($_POST['body_transparent_background_color'])){ $body_background_color = "ffffff";}
	  
	  
 $sql = "update pref set	
bg_color='$body_background_color' , 
font_color  ='$body_font_color' ,  
font_size='$body_font_font_size',
link_color='$body_link_color',
font_family='$font_fontfamily',
link_hover_color  ='$body_link_hover_color',
font_type_bold  ='$body_font_fonttype_Bold',
font_type_italic ='$body_font_fonttype_Italic' 
 WHERE id='$id'";
 $db->query($sql);
 
        echo "ok";

    
    

?>
