<?php

	define("DB_HOST", "localhost"); 
	define("DB_NAME", "site");
	define("DB_USER", "root");			
	define("DB_PASSWORD", "deppele");		
	


	
	 
define('LNG_NAME', 'utf8');
define('LNG_OPTIONS', 'utf8_general_ci');	
$db = new ezSQL_mysql(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
$db->query("set SESSION character_set_client = ".LNG_NAME."");
$db->query("set SESSION character_set_connection = ".LNG_NAME."");
$db->query("SET CHARACTER SET ".LNG_NAME."");
$db->query("SET COLLATION_CONNECTION = '".LNG_OPTIONS."'");


?>