$(document).ready(function() 
{
	$('.color').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		$(el).val(hex);
		$(el).ColorPickerHide();
	},
	onBeforeShow: function () {
		$(this).ColorPickerSetColor(this.value);
	}
})
.bind('keyup', function(){
	$(this).ColorPickerSetColor(this.value);
});

$(".colorpicker_submit").click(function() 
{
var background = $("#body_background_color").val();

var a_color = $("#body_link_color").val();
var ahover_color = $("#body_link_hover_color").val();
var body_font_color =$("#body_font_color").val();

$('body').css("background-color", "#"+background);
$('#body_background_color').css("background-color", "#"+background);
$('#body_font_color').css("color", "#"+body_font_color);

$('#container a').css("color", "#"+a_color);

$('#container a:hover').css("color", "#"+ahover_color);
$('body').css("color", "#"+body_font_color);

 //$('#container a') .animate({'color' : '#'+ahover_color+"'"}, 400);
//var valuerrrr= "'color' : '#"+ahover_color+"'";

//alert (valuerrrr);
    // $('#container a').animate({ 'color': 'blue'    }, 400);
   
   // .animate({'color': 'blue'}, 400);
   
/*   $('#container a').hover( 
  function() {
    $(this)
    //  .css('color','blue')
	.css("color", "#"+a_color)
      .animate({'color' : '#'+ahover_color+"'"}, 400);
	
  },
  function() {
    $(this)
      .animate({'color': 'blue'}, 400);
  }
);
   */
   
});


//$("#body_background_color").change(function() {
  $("#body_background_color input").keyup(function () {
alert ("ddd");
('#body_transparent_background_color').attr('checked', true);


}).keyup();



/*
$("#body_background_color").keyup(function() {
('#body_transparent_background_color').attr('checked', true);
});*/
$("#body_transparent_background_color").change(function() {
	$('#body_background_color').css("background-color", "#fff");
	$('body').css("background-color", "#fff");
	
/* 	var btrans_value= $('#body_transparent_background_color').attr("alt");
	if (btrans_value==0){
		$('#body_transparent_background_color').attr( 'alt', "1");
$('body').css("background-color", "#fff");
$('#body_background_color').css("background-color", "#fff");
$('#body_background_color').val("ffffff");
	}else {
		$('#body_transparent_background_color').attr( 'alt', "0");
	$('body').css("background-color", "");
$('#body_background_color').css("background-color", "");
$('#body_background_color').val("");	 
		}*/
	
});//body_transparent_background_color end

$("#body_font_fonttype_Bold").change(function() {
	var bold_value= $('#body_font_fonttype_Bold').attr("alt");
	if (bold_value==0){
$('body').css("font-weight", "bold");
$('#body_font_fonttype_Bold').attr( 'alt', "1");
	} else {
	$('body').css("font-weight", "normal");
	$('#body_font_fonttype_Bold').attr( 'alt', "0");
	}

});//body_font_fonttype_Bold


$("#body_font_size").change(function() {
	var body_font_sizer= $('#body_font_size').val();
$('body').css("font-size", body_font_sizer+'px');
//alert (body_font_sizer+' px');
});//body_font_fonttype_Bold

$("#body_font_fontfamily").change(onSelectChange);

function onSelectChange(){
var selected = $("#body_font_fontfamily option:selected");
//var value = "";
//if(selected.val() != 0){
//output = "You Selected " + selected.text();
//output = "id " + selected.val();
value = selected.val();
//alert (value);  }
$('body').css("font-family", value);
} 




$("#body_font_fonttype_Italic").change(function() {
	var italic_value= $('#body_font_fonttype_Italic').attr("alt");
	if (italic_value==0){
$('body').css("font-style", "italic");
$('#body_font_fonttype_Italic').attr( 'alt', "1");}
else {
	$('body').css("font-style", "normal");
	$('#body_font_fonttype_Italic').attr( 'alt', "0");
	}
});//body_font_fonttype_Italic

});






function save(page,form_eleman,messaga){
    var form = jQuery(form_eleman);
    sc = form.formSerialize();
	   // $('#ekleniyor').html('<center><img src="../images/loadingAnimation.gif"></center>');
    $.ajax({
        type: "POST",
        url: "ajax/" + page,
        data: sc,
		cache: false,
        success: function(msg){  
    if (msg=='ok')   {

$("#msg_box_warning").hide("fast");
$("#msg_box_ok").show("fast");
$("#msg_box_owrite").html(messaga);

   setTimeout(function(){
				  $("#msg_box_ok").fadeOut("slow", function () {
				  $("#msg_box_ok").hide("slow");
					  });   
				}, 8000);
				
				
}
else {
$("#msg_box_ok").hide("fast");
$("#msg_box_warning").show("fast");
$("#msg_box_wwrite").html(msg);

   setTimeout(function(){
				  $("#msg_box_ok").fadeOut("slow", function () {
				  $("#msg_box_ok").hide("slow");
					  });   
				}, 8000);
				
				
}}});}