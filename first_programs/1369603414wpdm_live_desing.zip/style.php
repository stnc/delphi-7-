<?php
header('Content-type: text/css');


include_once ('lib/class.ez_sql_core.php');
include_once ('lib/class.ez_sql_mysql.php');
require_once ('connect.php');





echo '*{ margin:0px; padding:0px}
body
{
	background-color:#fff;
	
	font-family:Arial, Helvetica, sans-serif;

	

}
#container
{

}

#container a
{
	color:#cca7cc;
	
}

#container a:hover
{
	color:#fff;
	
}


label
{

	margin-bottom:5px;
}

.color
{
	border:solid 1px #333;
	padding:4px;
	margin-top:8px;

}
.savebutton
{
	color:#fff;
	border:solid 1px #333;
	padding:5px;
	background-color:#000;
	font-weight:bold;
	
	
	
}
.system_messages li {
    font-size: 11px;
    left: 0;
    list-style: none outside none;
    margin: 0 0 7px;
    min-height: 1px;
    padding: 6px 0 6px 38px;
    position: relative;
    top: 0;
}
.green {
    background: repeat-x scroll 0 0 #C7E5C2;
    border: 1px solid #A2D399;
	color:#fff;
}
.yellow {
    background: repeat-x scroll 0 0 #EAE1B1;
    border: 1px solid #E0D182;
	color:#fff;
}


';

 define('GENEL_SITE_ADRES', '/');
 
if (isset($_GET['id']) && intval($_GET['id'])){
    $id = $_GET['id'];
	
	
}else {
    echo 'error';
	exit(); }
if (!$id){
	 $id = false;
}
else {

    //durum olay� kontrolu eklenecek
    $row_sql = 'select * from pref WHERE  ';
	
    if ($id)
   $row_sql .= 'id = '.$id.'  LIMIT 1;';

        
    $row_ = $db->get_row($row_sql, ARRAY_A);
    
    if (!$row_['id'])
	  {
	    echo 'error';
	exit(); 	}
		
    else {
		$bgcolor= stripslashes($row_['bg_color']);
       $font_color=stripslashes($row_['font_color']);
   $font_size=stripslashes($row_['font_size']);
    $font_family=stripslashes($row_['font_family']);
	   $link_color=stripslashes($row_['link_color']);
	   $bold= stripslashes($row_['font_type_bold']);
	   $italic=    stripslashes($row_['font_type_italic']);
   if ($bold=="1") {
   $bold_value='bold';
   } 
   else {$bold_value=''; }
   
	      if ( $italic=="1") 
		  {$italic_value='italic';} 
		  else {$italic_value='';}
		  
}
		}
echo "body {
background-color:#".$bgcolor.";
color:#".$font_color.";
font-size:".$font_size."px;
font-family:".$font_family.";
font-weight:". $bold_value.";
font-style:".$italic_value.";

}

#container a
{
	color:#".$link_color.";
	
}

"
;


?> 
