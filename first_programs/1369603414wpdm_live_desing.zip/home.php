<?php

 define('GENEL_SITE_ADRES', '/');
/*
 'Verdana, Geneva, sans-serif">Verdana, Geneva, sans-serif</option>',
' <option value="Georgia, \'Times New Roman\', Times, serif">Georgia, \'Times New Roman\', Times, serif</option>',
 '<option value="\'Courier New\', Courier, monospace">\'Courier New\', Courier, monospace</option>',
 '<option value="Arial, Helvetica, sans-serif">Arial, Helvetica, sans-serif</option>',
 '<option value="Tahoma, Geneva, sans-serif">Tahoma, Geneva, sans-serif</option>',
 '<option value="\'Trebuchet MS\', Arial, Helvetica, sans-serif">\'Trebuchet MS\', Arial, Helvetica, sans-serif</option>',
 '<option value="\'Arial Black\', Gadget, sans-serif">\'Arial Black\', Gadget, sans-serif</option>',
 '<option value="\'Times New Roman\', Times, serif">\'Times New Roman\', Times, serif</option>',
 '<option value=" \'Palatino Linotype\', \'Book Antiqua\', Palatino, serif"> \'Palatino Linotype\', \'Book Antiqua\', Palatino, serif</option>',
 ' <option value="\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif">\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif</option>',
 ' <option value="\'MS Serif\', \'New York\', serif">\'MS Serif\', \'New York\', serif</option>',
 ' <option value="\Lucida Console\', Monaco, monospace">\'Lucida Console\', Monaco, monospace</option>',
 ' <option value="\'Comic Sans MS\', cursive">\'Comic Sans MS\', cursive</option>',
 ' <option value="LucidaSansUnicode,LucidaGrande,Arial,">Other</option>'

*/
 $fonts = array(
 "Verdana, Geneva, sans-serif",
" Georgia, 'Times New Roman', Times, serif",
 "'Courier New', Courier, monospace",
 "Arial, Helvetica, sans-serif",
 "Tahoma, Geneva, sans-serif",
"Trebuchet MS', Arial, Helvetica, sans-serif",
 "Arial Black', Gadget, sans-serif",
 "Times New Roman', Times, serif",
 "Palatino Linotype', 'Book Antiqua', Palatino, serif",
 "Lucida Sans Unicode', 'Lucida Grande', sans-serif",
 "MS Serif', 'New York', serif",
 "Lucida Console', Monaco, monospace",
 "Comic Sans MS', cursive",
 " LucidaSansUnicode,LucidaGrande,Arial"
 
 
 );
 
 
     
	  
	  
	  
include_once ('lib/class.ez_sql_core.php');
include_once ('lib/class.ez_sql_mysql.php');
require_once ('connect.php');


    //durum olayı kontrolu eklenecek
    $row_sql = 'select * from pref WHERE id = 1  LIMIT 1; ';
	


        
    $row_ = $db->get_row($row_sql, ARRAY_A);
    

		$bgcolor= stripslashes($row_['bg_color']);
       $font_color=stripslashes($row_['font_color']);
   $font_size=stripslashes($row_['font_size']);
    $font_family=stripslashes($row_['font_family']);
	   $link_color=stripslashes($row_['link_color']);
	   $bold= stripslashes($row_['font_type_bold']);
	   $italic=    stripslashes($row_['font_type_italic']);
	   if ($bold=="1") {$bold_value='checked="checked"'; $bold_valuealt='1';} else {$bold_value=''; $bold_valuealt='0';}
	      if ( $italic=="1") {$italic_value='checked="checked"';$italic_valuealt='1';} else {$italic_value='';$italic_valuealt='0';}
	  
	   


		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Live Design Changing @stncweb</title>
<link rel="stylesheet" media="screen" type="text/css" href="css/colorpicker.css" />
<link rel="stylesheet" media="screen" type="text/css" href="style.css?id=1" />

        <script src="js/jquery-1.3.2.min.js" type="text/javascript"></script>
        <script src="js/jquery.form.js" type="text/javascript"></script>
        <script type="text/javascript" src="js/colorpicker.js"></script>
         <script type="text/javascript" src="js/action.js"></script>

</head>

<body>




<ul style="display:none;" id="msg_box_ok" class="system_messages">
                                <li class="green">
                                    <span class="ico"></span>
                                    <strong id="msg_box_owrite" class="system_title"></strong>
                                </li>
</ul>
                            
                            <ul style="display:none;" id="msg_box_warning" class="system_messages">
                                <li class="yellow">
                                    <span class="ico"></span>
                                    <strong id="msg_box_wwrite" class="system_title"></strong>
                                </li>
                            </ul>
                            <div id="container">
<p><a href="#">test</a></p>
                      <p>  
                      <a href="#">test</a></p>
                      <p> 
                        <a href="#">test</a> 
                      </p>
                      </div>
                      </p>
<form action="javascript:void(0);" name="aktar" id="sayfa_ekle" class="search_form general_form" method="post">
<p>
<input type="hidden" value="1" name="id" />
        <label for="body_background_color" ><br />
          <br />
          Background Color:</label>
        <input type="text" value="<?php echo $bgcolor ;?>" class="color" id="body_background_color" name="body_background_color"  >
        
         <input type="checkbox" value="transparent" id="body_transparent_background_color" name="body_transparent_background_color" property="body_background_color" alt="0" selector="body">Transparent
     
         <label ><br />
        <br />
  Font Type:</label> 
      <input type="checkbox"   value="bold" <?php echo $bold_value ;?>  selector="body" name="body_font_fonttype_Bold" alt="<?php echo $bold_valuealt;?>" id="body_font_fonttype_Bold">
        <label for="body_font_fonttype_Bold"> Bold</label> 
        
      <input type="checkbox"  value="italic" selector="body" alt="<?php echo $italic_valuealt;?>" <?php echo $italic_value ;?> name="body_font_fonttype_Italic" id="body_font_fonttype_Italic">
        <label for="body_font_fonttype_Italic"> Italic<br />
          <br />
        </label>
      
      
          <label for="body_font_font_size" >Font Size:</label>
<input type="text"  value="<?php echo $font_size ;?>"   id="body_font_size"  
name="body_font_font_size" > px</p>
     <p>&nbsp;</p>
  <p>
  
  <label for="body_font_fontfamily" >Font Family:</label>
    <select property="body_font-family" selector="body" name="font_fontfamily" id="body_font_fontfamily">
	
<?php 
foreach ($fonts as $i => $value) {
if ( $font_family==$fonts[$i])
	echo '<option selected="selected" value="'.$fonts[$i].'">'.$fonts[$i].'</option> ';
else 
	echo '<option value="'.$fonts[$i].'">'.$fonts[$i].'</option> ';
	}


?>

	

 



  </select>

      <label for="body_color" ><br />
        <br />
    Link Color:</label>
    <input type="text" class="color" id="body_link_color"  value="<?php echo  $link_color ;?>" name="body_link_color"  selector="a" /> 

        <label for="body_link_hover_color"><br />
          <br />
        Link Hover Color:</label>
    <input type="text" class="color" value="<?php echo $bgcolor ;?>" id="body_link_hover_color" name="body_link_hover_color"   />


    <label for="body_font_color" ><br />
      <br />
    Font Color:</label>

  <input type="text" class="color"  value="<?php echo $font_color ;?>" id="body_font_color" name="body_font_color" selector="body" / > 
</p>
<input type="submit" onclick=" save('save.php','#sayfa_ekle','update record');" class="savebutton" value="save" name="submit">
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>


</body>
</html>
