
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_surname` varchar(255) DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `comments` text,
  `ip_adress` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `edit_date` datetime DEFAULT NULL,
  `status_` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 ROW_FORMAT=DYNAMIC;



INSERT INTO `comments` VALUES (1,'hakan alper','dd@fff.com','s�per video',NULL,'2011-05-01',NULL,1);
INSERT INTO `comments` VALUES (5,'denen ozle','dd@fff.com','denem yorumu ',NULL,'2011-07-01',NULL,1);
INSERT INTO `comments` VALUES (6,'ahme alpi','dd@fff.com','iyi g�zel',NULL,'2011-02-01',NULL,1);
INSERT INTO `comments` VALUES (7,'denen ozle1','dd@fff.com','iyi g�zel',NULL,'2011-06-01',NULL,1);
INSERT INTO `comments` VALUES (8,'de2','dd@fff.com','iyi g�zel2Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (9,'de3',NULL,'iyi g�zel3',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (10,'de4',NULL,'iyi g�zel5',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (11,'de5',NULL,'iyi g�zel6',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (12,'de6',NULL,'iyi g�zel7',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (13,'de7',NULL,'iyi g�zel8',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (14,'de8',NULL,'iyi g�zel8990',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (15,'de9',NULL,'iyi g�zelds fdsdsfg',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (16,'de10',NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (17,'de11','dd@fff.com','iyi g�zelvd dfgdfgdf dfg',NULL,'0000-00-00 00:00:00',NULL,1);

