<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="jquery-1.6.2.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="comment.css" type="text/css" media="all" />
<script type="text/javascript">
function paging(page,id,sayfa){
$.ajax({
type: 'GET',
 url: 'ajax/'+sayfa,
 data: 'page='+page+'&id='+id,
success: function(sonuc) {
$('#comment_block').html(sonuc);
}
});
return false;
}

</script>


</head>

<body>
<?php 
include_once ('lib/class.ez_sql_core.php');
include_once ('lib/class.ez_sql_mysql.php');
require_once ('connect.php');


include 'lib/class.kgPager.ajax.php';


$total_records = $db->get_var("SELECT count(id) from comments  where status_=1  ");
$kgPagerOBJ = & new kgPager();
$scroll_page = 10; // paging
$per_page = 3; // page total
$git_sayfa = 'ajax_video_yorumlar.php';
$current_page = $_GET['page'];
$pager_url = 1;// $id;
$inactive_page_tag = 'class="current_page"';
$previous_page_text = '&lt; Önceki Sayfa';
$next_page_text = 'Sonraki Sayfa &gt;';
$first_page_text = '&lt;&lt;';
$last_page_text = '&gt;&gt;';
$pager_url_last = 1;//$id;
$kgPagerOBJ->pager_set($pager_url, $total_records, $scroll_page, $per_page, $current_page, $inactive_page_tag, $previous_page_text, $next_page_text, $first_page_text, $last_page_text, $pager_url_last, $git_sayfa);

$first_page = $kgPagerOBJ->first_page;
$previous_page = $kgPagerOBJ->previous_page;
$page_links = $kgPagerOBJ->page_links;
$next_page = $kgPagerOBJ->next_page;
$last_page = $kgPagerOBJ->last_page;
echo 'toplam yorum: '.$total_records;

?>

<div id="comment_block">


<?php 

function time_stamp($session_time)
{
$time_difference = time() - $session_time ;
$seconds = $time_difference ;
$minutes = round($time_difference / 60 );
$hours = round($time_difference / 3600 );
$days = round($time_difference / 86400 );
$weeks = round($time_difference / 604800 );
$months = round($time_difference / 2419200 );
$years = round($time_difference / 29030400 );
// Seconds
if($seconds <= 60)
{

  return "$seconds saniye önce";
}
//Minutes
else if($minutes <=60)
{

   if($minutes==1)
  {
 //  return "";
     return "Bir dakika önce";
   }
   else
   {
  
	  return $minutes."dakika önce";
	
   }

}
//Hours
else if($hours <=24)
{

   if($hours==1)
  {

    return 'Bir saat önce';
  }
  else
  {
 return "$hours saat önce";
  }
 
}
//Days
else if($days <= 7)
{

  if($days==1)
  {
   
     return 'Bir gün önce';
  }
  else
  {
 
     return "$days gün önce";
   }

}
//Weeks
else if($weeks <= 4)
{

   if($weeks==1)
  {
   
     return 'bir hafta önce';
   }
  else
  {
 
     return "$weeks hafta önce";
  }

}
//Months
else if($months <=12)
{

   if($months==1)
  {
 
     return 'bir ay önce';
   }
  else
  {
   
     return "$months ay önce";
   }

}
//Years
else
{

   if($years==1)
   {
    
	  return 'bir yıl önce';
   }
   else
  {
   
	  return "$years yıl önce";
   }

}

}
echo '<div class="comment_pager">';

 echo $first_page;
 echo $previous_page;
 echo $page_links;
 echo $next_page;
 echo $last_page;

echo '</div><!--comment pager-->';

//yorumlar


/*  $sql = "SELECT id,name_surname,comments,add_date from vimhub_video_comments
where status_=1 and video_id=1 limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page; */

/*

 echo $sql = "SELECT vcomlike.id as comlike_id, vcom.name_surname,vcom.comments,vcom.add_date,likes,unlikes 
from vimhub_video_comments as vcom, vimhub_video_comments_likes as vcomlike where vcom.status_=1 and 
vcom.video_id=".$vid_id." and vcom.video_id=vcomlike.video_id and vcomlike.comment_id=vcom.id  limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page;

*/
 $sql = "SELECT id, name_surname,comments,add_date
from comments  where status_=1  limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page;
$comments = $db->get_results($sql, ARRAY_A);
if ($comments != '') {
    foreach ($comments as $comment) {
    $com_id = $comment['id'];

       $ad = $comment['name_surname'];
       // $tar = $comment['tarih'];
        $dat = strtotime($comment['add_date']);
        $zaman_once = time_stamp($dat);
        $yorum = $comment['comments'];
   

?>

<div class="comment_box_v1">
<div class="profil_img">
<img src="images/comment_BlackTheme.png" alt="prof" />
</div><!--//profil_img-->
<ul>
<li class="user_info">
<img width="16" height="16" alt="user" src="images/user.png" />
<strong><?php echo $ad; ?></strong>
</li>
<li class="mini_date">
<img width="12" height="14" alt="date" src="images/calendar.png" /> <?php echo $zaman_once ; ?>
</li>
<li>
<img width="16" height="16" alt="yorum" src="images/comment.png" />  <?php echo  $yorum; ?></li>
<li class="mini_date">


</li>
</ul>
</div><!--//comment_box_v1-->
 <?
	}
}
?>
<div class="comment_pager">
<?php 
 echo $first_page;
 echo $previous_page;
 echo $page_links;
 echo $next_page;
 echo $last_page;
 ?>
</div><!--comment pager-->
</div><!--//comment_block-->
</body>
</html>