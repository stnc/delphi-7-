
DROP DATABASE IF EXISTS `sozler`;
CREATE DATABASE `sozler` /*!40100 DEFAULT CHARACTER SET latin5 */;
USE `sozler`;

#
# Source for table sozler
#

DROP TABLE IF EXISTS `sozler`;
CREATE TABLE `sozler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `soz` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin5;

#
# Dumping data for table sozler
#
LOCK TABLES `sozler` WRITE;
/*!40000 ALTER TABLE `sozler` DISABLE KEYS */;

INSERT INTO `sozler` VALUES (1,'Eline, diline, beline sahip ol ki, k�t�l�kler senden uzak dursun.');
INSERT INTO `sozler` VALUES (2,'Musibet zekay�e�itir');
INSERT INTO `sozler` VALUES (3,'Ki�inin s�z�, amelinden �ok olursa akl�noksand�r.');
INSERT INTO `sozler` VALUES (4,'Ne kadar okursan oku, bilgine yak���r �ekilde davranmazsan cahilsin demektir.');
INSERT INTO `sozler` VALUES (5,'Felaketler, ayak seslerini duymayanlara geliyorum demez.');
INSERT INTO `sozler` VALUES (6,'Harekette birlik olmazsa, fikirde bilgi faydas�zd�r.');
INSERT INTO `sozler` VALUES (7,'Zalime, ancak, onu zul�mden al�koymak i�in yard�m et.');
INSERT INTO `sozler` VALUES (8,'Yar�n, yorgun kimselerin de�il, rahatlar�na k�yabilenlerindir.');
INSERT INTO `sozler` VALUES (9,'Kuvvetine g�venenler, korkutma k���kl���nde bulunmazlar.');
INSERT INTO `sozler` VALUES (10,'Tarihte her hareket hep bir ki�inin aya�a kalkmas�yla ba�lar.');
INSERT INTO `sozler` VALUES (11,'Kesilmis koyuna, derisini y�z�lmesi elem vermez.');
INSERT INTO `sozler` VALUES (12,'Kendini hak ile me�gul etmezsen, bat�l seni i�gal eder.');
INSERT INTO `sozler` VALUES (13,'Her�eyi bilmek �ok k�t�d�r.');
INSERT INTO `sozler` VALUES (14,'Allah\'a itaat etmekle, O\'na ��kretmi� olursunuz.');
INSERT INTO `sozler` VALUES (15,'Ak�ll� olan Allah\'tan korkar.');
INSERT INTO `sozler` VALUES (16,'�limsiz ibadette, tefekk�rs�z Kur\'an tilavetinde hay�r yoktur.');
INSERT INTO `sozler` VALUES (18,'El a�az�na bakan kar�s�n� tez bo�ar.');
INSERT INTO `sozler` VALUES (19,'Gercek dost, arkada��n�n kusurunu g�r�nce onu uyar�r. Fakat bu kusurlar�ba�kalar�na a��klamaz.');
INSERT INTO `sozler` VALUES (20,'�ahsi gayret yuvayi, toplu gayret vatani ayakta tutar.');
INSERT INTO `sozler` VALUES (21,'K���k insanlar�n gururu b�y�k olur.');
INSERT INTO `sozler` VALUES (22,'Kitap akl�n ilac�d�r.');
INSERT INTO `sozler` VALUES (28,'Allah\'tan korkmayandan korkulur.');
/*!40000 ALTER TABLE `sozler` ENABLE KEYS */;
UNLOCK TABLES;


