<?php
	define("DB_USER", "root");			
	define("DB_PASSWORD", "");			
	define("DB_NAME", "sozler");	
	define("DB_HOST", "localhost");	
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD)
	or die ('Sorun var : '.mysql_error());
	mysql_select_db(DB_NAME) or die ('veritabani yok ');


	$query = "select * from sozler order by rand() limit 1";
	$result = mysql_query($query) or die (mysql_error());
	while ($sozzz = mysql_fetch_assoc($result))
	{


		echo $sozzz["soz"];



	}
?>