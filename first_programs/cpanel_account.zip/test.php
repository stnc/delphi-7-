<?php
//include the whm class file.
require_once('whm.php');
if (isset ($_POST['submit'])){
// create a new instance of whm class
$test= new whm;

//initilize the whm object 
//you can use you hostname or an IP below 
//you can find you whm hash when yopu login into your whm account clickong on "Setup Remote Access Key" link.
$test->init('whm link','usernama','hash key Setup Remote Access Key');

//This will output the cpanel/whm version.  
$version= $test->version();
echo "Cpanel/whm version : $version <br>";

//This way you can create an account. 
//This function will return a result set as an array in success and will return false on fail.
	$user = $_POST['user'];
		$pass = $_POST['pass'];
		$username = $_POST['username'];
$result=$test->createAccount($user,$username,$pass,'paketinizin ad� ');

//check if creating account was successfull or not.
if($result)
{
	//print the result set
	//print_r($result);
	//echo $result->$status[0];
	
	
}
else
{
	//You can get the errors like this.
	print_r($test->errors);
}

}
?>

<html>
<head><title>cPanel hesap a�</title></head>
<body>
<?php echo '<div style="color:red">'.$msg.'</div>'; ?>
<h1>cPanel hesap a� </h1>
<form name="frmEmail" method="post">
<table width="400" border="0">
<tr><td>domain :</td><td><input name="user" size="20" type="text" /></td></tr>
<tr><td>kullanc� ad�</td><td><input name="username" size="20"  type="text"  /></td></tr>
<tr><td>�ifre:</td><td><input name="pass" size="20" type="password" /></td></tr>

<tr><td colspan="2" align="center"><hr /><input name="submit" type="submit" value="yap" /></td></tr>
</table>
</form>
</body>
</html>