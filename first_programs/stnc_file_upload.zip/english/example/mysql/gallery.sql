﻿

DROP DATABASE IF EXISTS `stnc_file_upload`;
CREATE DATABASE `stnc_file_upload` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `stnc_file_upload`;

#
# Source for table gallery
#

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `galeri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_1` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

