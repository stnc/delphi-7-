<?php 
session_start();
//header("Content-Type: text/html; charset=utf-8");



    require_once ('../stnc_upload-ajax_class.php');
    $sonuc = '';
    
 
        $mime_types = array('jpg', 'gif', 'png');
        $Uploader = & new stnc_file_upload();
        //$Uploader->picture_edit = TRUE;
        
        $Uploader->first_values('st_', '_nc', 'KB', '120');
        
        $Uploader->picture_edit_values (true, 640, 480, 'MB', '1.00');
        $Uploader->picture_edit_thumb_values(true, '../uploads/thumb', 114, 121, '_thumb');
        $Uploader->uploader_set($_FILES['file'], '../uploads', $mime_types);

		$RE1 = $Uploader->uploaded_files[0];

             $Uploader->result_report();
      echo $sonuc;
		


?>
