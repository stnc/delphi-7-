<?php 

require_once ('../stnc_upload.php');
 if ($_FILES) {
    
        echo '<div id="reports">';
        

		      $mime_types = array('jpg','gif','pdf','exe'); // izin verilecek olan dosya tipleri
		
        $Uploader = & new stnc_file_upload();
		
	  $Uploader->first_values('st_','_nc','KB','120') ;

	  $Uploader->picture_edit_values(true,640 ,480 , 'MB' ,'1.00') ;

 	  $Uploader->picture_edit_thumb_values( true, 'uploads/thumb',150,150,'_thumb' ) ;
     
        $Uploader->uploader_set($_FILES['file'], './uploads', $mime_types); 
        
        $Uploader -> result_report(); 
        
        echo '</div>';
        
    }
    
?>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-9">
        <meta name="Author" content="Stnc Web Hizmetleri-info@stncweb.net-Selman Tunc">        
        <link rel="stylesheet" type="text/css" href="css/style.css">
           
      </head>
   
         <form method="post" id="file_upload_form" action="" enctype="multipart/form-data" content="text/html; charset=utf-8">
            <table width="419" height="29" border="0">
                <tr>
                    <th colspan="2" scope="col" class="table_baslik">
                     dosya ekleme
                        B&ouml;l&uuml;m&uuml;
                    </th>
                </tr>
                <?php 
              
                $max_no_img = 4;
                
                for ($res = 1; $res <= $max_no_img; $res++) { 
                    
                ?>
                <tr >
                    <td width="96">
                       Dosya <?php echo $res?>
                    </td>
                    <td width="447">
                        <input type="file" id="picture_<?php echo $res?>" size="%50" name="file[]" />
                    </td>
                    <?php } ?>
                </tr>
        
            </table>
			<input class="submit" type="submit" name="submit" value="Save">
             
		
        </form>