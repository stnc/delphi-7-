<?php 
	$hostname_config = "localhost";
  $username_config = "root";
 $password_config = "";
 $database_config = "stnc_file_upload";

$config = mysql_connect($hostname_config, $username_config, $password_config) or trigger_error(mysql_error(), E_USER_ERROR);

if (!@mysql_connect($hostname_config, $username_config, $password_config)) die ('error'.mysql_error());
if (!@mysql_select_db($database_config)) die (mysql_error());

 function thumb_path($filename,$eklenecek_taki,$hedef_yol) {
$dosya_bilgi = pathinfo($filename);
$dosya_isim=$dosya_bilgi['filename']; 
$uzanti='.'.$dosya_bilgi['extension'];
return $son_ekli_isim=$hedef_yol.'/thumb/'.$dosya_isim.'_thumb'.$uzanti;
}
require_once ('../stnc_upload.php');
 if ($_FILES) {
    
        echo '<div id="reports">';
        

        $mime_types = array('jpg', 'gif', 'png');
        $Uploader = & new stnc_file_upload();
        //$Uploader->picture_edit = TRUE;
        
        $Uploader->first_values('st_', '_nc', 'KB', '120');
        
        $Uploader->picture_edit_values (true, 640, 480, 'MB', '1.00');
        $Uploader->picture_edit_thumb_values(true, 'uploads/thumb', 114, 121, '_thumb');
     
        $Uploader->uploader_set($_FILES['file'], './uploads', $mime_types); 
        
        $Uploader -> result_report(); // yukleme ayrintilarini gosterir
        //Eğer dosya isimleri bir veritabanı tablosuna kaydetmek istenirse aşagıdakini kullanın
      /* for ($i = 0; $i < count($Uploader->uploaded_files); $i++) {
            echo '<br>'.$Uploader->uploaded_files[$i];
        }
    */
        
        echo '</div>';
		

		
		$file_name= $_POST['file_name'] ;
		$RE1 = $Uploader->uploaded_files[0];//her resim degeri için burası artırılablir.
 $sql = "INSERT INTO `gallery` (`id`,`file_name`,`picture_1`) VALUES ( NULL,'$file_name','$RE1'); ";
 $result = mysql_query ($sql);
    }
    
?>

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=1254">
        <meta name="Author" content="Stnc Web Hizmetleri-info@stncweb.net-Selman Tunc">        
        <link rel="stylesheet" type="text/css" href="css/style.css">
     
      </head>


       <form method="post" id="file_upload_form" action="" enctype="multipart/form-data" content="text/html; charset=utf-8">
            <table width="419" height="29" border="0">
                <tr>
                    <th colspan="2" scope="col" class="table_baslik">
                        Resim Ekleme
                        B&ouml;l&uuml;m&uuml;
                    </th>
                </tr>
                <?php 
              
                $max_no_img = 1;
                
                for ($res = 1; $res <= $max_no_img; $res++) { 
                    
                ?>
                <tr >
                    <td width="92">
                        Resim
                    </td>
                    <td width="447">
                        <input type="file" id="picture_<?php echo $res?>" size="%50" name="file[]" />
                    </td>
                    <?php } ?>
                </tr>
           
            <tr >
                <td width="131">
                    <strong>Resim Ba&#351;l&#305;&#287;&#305; </strong>
                </td>
                <td width="278" >
                    <input name="file_name" type="text" size="45"  >
                </td>
            </tr>

            </table>

			<input class="submit" type="submit" name="submit" value="save" >

        </form>
<?php	
	$result =mysql_query('SELECT id,file_name,picture_1  FROM gallery ORDER BY id'); 
	while ($row = mysql_fetch_assoc($result))
{ ?>
<a href="<?php echo 'uploads/'.$row['picture_1']; ?>" >
<img src="<?php if ($row["picture_1"]=='') echo 'uploads/gallery.png'; else 
 echo thumb_path($row["picture_1"],'_nc',"uploads")  ;?>" > </a>
 <?php echo 'thumb picture  -->'.$row['file_name']; ?><br>

 <?php } ?>