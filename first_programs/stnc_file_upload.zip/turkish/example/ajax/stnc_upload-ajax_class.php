<?php 
/**
 *################################################################################
 *#                           Stnc Multi uploader
 *################################################################################
 *# Class Name :stnc multi uploader
 *# Script-Version:     3.0
 *# File-Release-Date:  22/12/2009 21:34
 *# update Date : 12,01,2010
 *# Php Version  : PHP 4.3.0+
 *# Official web site and latest version:  selmantunc.com
 *#==============================================================================
 *# Authors: selman tunc (selmantunc@gmail.com)
 *# Copyright � 2010 stncweb.net  -   selmantunc.com    All Rights Reserved.
 *#
 *################################################################################
 * | This program is free software; you can redistribute it and/or             |
 * | modify it under the terms of the GNU General var License              	   |
 * | as published by the Free Software Foundation; either version 2            |
 * | of the License, or (at your option) any later version.                    |
 * |                                                                           |
 * | This program is distributed in the hope that it will be useful,           |
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
 * | GNU General var License for more details.                            	   |
 * |                                                                           |
 * +---------------------------------------------------------------------------+
 */

 
 /**
 * STNC upload Class
 *
 * @version   3.0
 * @author    SeLman Tun� <selmantunc@gmail.com >
 * @license   http://opensource.org/licenses/gpl-license.php GNU var License
 * @copyright SeLman Tun�
 * @package   upload
 * @subpackage external
 */
 
//yeni
//  function upload_file_size($file)  fonksiyonu kullan�lm�yordu kalkt�
//  eskiden  dosya uzant�lar�n�n komtrolu upload() i�inde yap�l�yordu veritabn�nda ve ajaxda sorun yaratacag� d���n�lerek ayr�ld�
//  fakat i� g�r�yordu mant�l� �al���yordu uyumusuz tipdekini ��kar�yor di�erlerini yukluyordu version 2 de deste�i devam ediyor


/**
 * @package   upload
 * @subpackage external
 */
 
//no error hata gostermesin diye gercek resim olup olmad�g�nda hata verir
//$error_report_old = error_reporting(0);

class stnc_file_upload {

    /**
     * resim boyutland�rma olcakm�
     *
     * @access puplic
     * @var boolean
     */
    var $picture_edit = FALSE;
    
    /**
     * resim geni�li�i
     *
     * @access puplic
     * @var integer
     */
    var $pic_width = 640;
    
    /**
     * resim uzunlugu
     *
     * @access puplic
     * @var integer
     */
    var $pic_height = 480;
    
    /**
     * resimin �nizleme hai al�ncak m�
     *
     * @access puplic
     * @var boolean
     */
    var $thumb_picture = FALSE;
    
    /**
     * �znileme hali nerede saklanacak
     *
     * @access puplic
     * @var string
     */
    var $thumb_pic_dir = '';
    
    /**
     * �nizlemeye sonuna ek gelecek mi �rnek creek.jpg  --> creek_thumb.jpg
     *buras� veritabn�nda saklayanlar i�in gerekli olablir
     *ayn� zamnda veritab�nnda thumb degeri saklaman�z gerekmez son_ek ile resmi al�rs�n�z
     *ayr�nt�l� bilgi i�in �rneklere bak�n
     *
     * @access puplic
     * @var string
     */
    var $thumb_pic_extension = '_thumb';
    
    /**
     * �znileme resmi k���k hali geni�li�i
     *
     * @access puplic
     * @var integer
     */
    var $thumb_pic_width = 300;
    
    /**
     * �znileme resmi k���k hali geni�li�i
     *
     * @access puplic
     * @var integer
     */
    var $thumb_pic_height = 300;
    
    /**
     * resimin onune ek getirilecek mi
     *
     * @access puplic
     * @var string
     */
    var $_prefix = 'stnc_';
    
    /**
     * resimin sonuna ek getirilecekmi
     *
     * @access puplic
     * @var string
     */
    var $suffix_ = '_stnc';
    
    /**
     * resimin dosya turu
     *
     * Byte     = B
     * Kilobyte = KB
     * MegaByte = MB
     * GigaByte = GB // not support but only just . :) desteklenmez
     *
     * @access puplic
     * @var string
     */
    var $pic_size_type = 'MB';
    
    /**
     * resimin boyutu
     *
     * @access puplic
     * @var string
     */
    var $picture_size = '1.00';
    
    /**
     * resim haricindekilerin dosya tipi
     *
     * @access puplic
     * @var string
     */
    var $size_type_file = 'KB';
    
    /**
     * resim haricindekilerin dosya boyutu
     *
     * @access puplic
     * @var string
     */
    var $size_files = '1.00';
    
    /**
     * upload a gonderilen dosyalar
     *
     * @access puplic
     * @var array
     */
    var $files = array();
    
    /**
     * hata kayd�
     *
     * @access puplic
     * @var string
     */
    var $error = NULL;

    
    /**
     * dosya kay�t klasoru
     *
     * @access puplic
     * @var string
     */
    var $upload_dir = NULL;
    
    /**
     * upload basar�l�m�
     *
     * @access puplic
     * @var boolean
     */
    var $uploaded = false;
    
    /**
     * upload edilen dosyalar
     *
     * @access puplic
     * @var array
     */
    var $uploaded_files = array();
    
    /**
     * yeni dosya ad�
     *
     * @access puplic
     * @var string
     */
    var $new_file_name = NULL;
    
    /**
     * bilgilendirme
     *
     * @access puplic
     * @var string
     */
    var $info = NULL;

    
    /**
     
     *uzant� kontrolu,upload,yeni isim atama,resim d�zenleme
     *
     * @access puplic
     * @return boolean uploaded
     */
     
    function upload() {
        if (!$this->error) {
            //for i�inde her dosya adetince dongu yap�l�r
            for ($i = 0; $i < count($this->files['tmp_name']); $i++) {
            
                //file_name_control fonksiyonu ile olu�turulan yeni isim new_file_name ad�na atama yap�l�r
                $this->new_file_name = $this->file_name_control($this->files['name'][$i]);
                //dosylar klasore yeni imi ile upload edilir
                move_uploaded_file($this->files['tmp_name'][$i], $this->upload_dir.'/'.$this->new_file_name);
                if ($this->picture_edit) { //eger picture edit  (resim d�znleme) true ise
                    //resimin uzant�s�na gore yeniden boyutland�rma i�lemine ge�ilir
                    if ($this->file_extension($this->files['name'][$i]) == 'jpg' || $this->file_extension($this->files['name'][$i]) == 'jpeg')
                        $this->image_edit_jpe_g($this->upload_dir.'/'.$this->new_file_name);
                    elseif ($this->file_extension($this->files['name'][$i]) == 'gif')
                        $this->image_edit_gif($this->upload_dir.'/'.$this->new_file_name);
                    elseif ($this->file_extension($this->files['name'][$i]) == 'png')
                        $this->image_edit_png($this->upload_dir.'/'.$this->new_file_name);
                }
                if ($this->thumb_picture) {//k���k resim yapma true ise
                    //resimin uzant�s�na gore yeniden boyutland�rma i�lemine ge�ilir
                    if ($this->file_extension($this->files['name'][$i]) == 'jpg' || $this->file_extension($this->files['name'][$i]) == 'jpeg')
                        $this->image_edit_thumb_jpe_g($this->upload_dir.'/'.$this->new_file_name);
                    elseif ($this->file_extension($this->files['name'][$i]) == 'gif')
                        $this->image_edit_thumb_gif($this->upload_dir.'/'.$this->new_file_name);
                    elseif ($this->file_extension($this->files['name'][$i]) == 'png')
                        $this->image_edit_thumb_png($this->upload_dir.'/'.$this->new_file_name);
                }
                //her�ey dogru ise bilgilendirmelere deger atan�r
                $this->uploaded_files[] = $this->new_file_name;
                //$this->info .= '<li><strong>'.$this->files['name'][$i].' isimli dosya, <strong>'.$this->new_file_name.'</strong> ismiyle y�klendi<br />(~'.round($this->files['size'][$i] / 1024, 2).' kb). Dosya Tipi : '.$this->file_extension($this->files['name'][$i]).'</li>';
                $this->info .= '1:'.$this->files['name'][$i].' isimli dosya '.$this->new_file_name.' ismiyle y�klendi<br />';
            }
            return $this->uploaded = true;
        }
    }

    
    /**
     *bad_character_rewrite
     *uyumsuz ve gereksiz karakterleri temizler
     *
     * @access puplic
     * @param  string  $text dosya isimleri
     * @return string $text_rewrite
     */
    function bad_character_rewrite($text) {
    
        $first = array("\\", "/", ":", ";", "~", "|", "(", ")", "\"", "#", "*", "$", "@", "%", "[", "]", "{", "}", "<", ">", "`", "'", ",", " ", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�");
        $last = array("_", "_", "_", "_", "_", "_", "", "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", "", "_", "_", "g", "G", "u", "U", "s", "S", "i", "I", "o", "O", "c", "C");
        $text_rewrite = str_replace($first, $last, $text);
        return $text_rewrite;
    }

    
    /**
     *file_extension
     *dosya uzant�s� bulur
     *
     * @access puplic
     * @param  string $file_name dosya isimleri
     * @return string
     */
    function file_extension($file_name) {
        $file_extension = strtolower(substr(strrchr($file_name, '.'), 1));
        return $file_extension;
    }

    
    /**
     *dizin kontolleri ve yazma izinlerine bakar
     *
     * @access puplic
     * @param  string
     * @return string
     */
    function upload_dir($upload_dir) {
        // dizin var mi?
        if (!is_dir($upload_dir)) {
            $this->error .= '2:'.$upload_dir.' isminde bir dizin bulunamad�!</li>';
        }
        // dizinin yazma izni var mi?
        if (is_dir($path) && !is_writable($upload_dir)) {
            $this->error .= '3:'.$upload_dir.' isimli dizine yazma izni bulunmamaktad�r!</li>';
        }
        /*thumb folder control*/
        if ($this->thumb_picture) {
            if (!is_dir($this->thumb_pic_dir)) {
                $this->error .= '4:'.$this->thumb_pic_dir.' ismindeki k���k resim  dizini bulunamad�!</li>';
            }
            // dizinin yazma izni var mi?
            if (is_dir($path) && !is_writable($this->thumb_pic_dir)) {
                $this->error .= '5:'.$this->thumb_pic_dir.'ismindeki k���k resim  dizinine yazma izni bulunmamaktad�r!</li>';
            }
        }
        
        $this->upload_dir = $upload_dir;
    }

    
    /**
     *kotu karakter temizler,ayn� isimde dosya varm� kontrol eder,rastgele say� uret,onek verir,son ek ver
     *rastgele say� uretme ve ayn� dosya varm� harici fonsiyondur
     *
     * @access puplic
     * @param  array
     * @return string
     */
    function file_name_control($file_name) {
        //
        $file_name = $this->bad_character_rewrite($file_name);//kotu karakter temizler
        if (!file_exists($this->upload_dir.'/'.$file_name)) { //ayn� isimde dosya varmo kontrol et
            return $file_name;
        } else {
            $unique_name = rand(0001, 9999).'_'.rand(0001, 99999).'_'.$file_name;//isim i�in rastgele say� uret
            
            $_prefix = $this->Prefix($unique_name, $this->_prefix);//on ver
            
            return $_suffix = $this->Suffix($_prefix, $this->suffix_); //son ek ver
        }
    }
    
    /**
     *son ek ver ornek creek.jpg -> creek_ek.jpg
     *
     * @access puplic
     * @param  string $filename
     * @param  string $suffix
     * @return string
     */
    function Suffix($filename, $suffix) {
        $file_info = pathinfo($filename);
        $file_name = $file_info['filename'];
        $ext = '.'.$file_info['extension'];
        return $result = $file_name.$suffix.$ext;
        
    }
    
    /**
     *�n ek ver "creek.jpg -> ek_creek.jpg"
     *
     * @access puplic
     * @param  string $filename dosya ad�
     * @param  string $prefix onune verilecek isim
     * @return string
     */
    function Prefix($filename, $prefix) {
        $file_info = pathinfo($filename);
        $file_name = $file_info['filename'];
        $ext = '.'.$file_info['extension'];
        return $result = $prefix.$file_name.$ext;
    }

    
    /**
     * dosya bilgileri
     *
     * @access puplic
     * @param  array
     */
    function files($files) {
        if ($files) {
            for ($i = 0; $i < count($files); $i++) {
                if ($files['name'][$i]) {
                    $this->files['tmp_name'][] = $files['tmp_name'][$i];
                    $this->files['name'][] = $files['name'][$i];
                    $this->files['type'][] = $files['type'][$i];
                    $this->files['size'][] = $files['size'][$i];
                    
                }
            }
        }
    }

    
    /**
     * jpg turu yeniden boyutland�rma
     *
     * @access puplic
     * @param  string $source_target
     */
    function image_edit_jpe_g($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);//boyut kontrol
        if ($width_org >= $width_ && $height_org >= $height_) {
            $picture = imagecreatetruecolor($width_, $height_);
            $source = imagecreatefromjpeg($source_target);//jpg olu�tur
            imagecopyresampled($picture, $source, 0, 0, 0, 0, $width_, $height_, $width_org, $height_org);
            //resmi uzerine aktar
            imagejpeg($picture, $source_target);//olu�sun
            
        }
    }
    
    /**
     *gif turu yeniden boyutland�rma
     *
     * @access puplic
     * @param   string
     */
    function image_edit_gif($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);
        if ($width_org >= $width_ && $height_org >= $height_) {
            $picture = imagecreatetruecolor($width_, $height_);
            $source = imagecreatefromgif($source_target);
            imagecopyresampled($picture, $source, 0, 0, 0, 0, $width_, $height_, $width_org, $height_org);
            imagegif($picture, $source_target);

            
        }
    }
    
    /**
     *png turu yeniden boyutland�rma
     *
     * @access puplic
     * @param   string
     */
    function image_edit_png($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);
        if ($width_org >= $width_ && $height_org >= $height_) {
            $picture = imagecreatetruecolor($width_, $height_);
            $source = imagecreatefrompng($source_target);
            imagecopyresampled($picture, $source, 0, 0, 0, 0, $width_, $height_, $width_org, $height_org);
            imagepng($picture, $source_target);
        }
    }
    
    /**
     *k���k resim yap jpg turu yeniden boyutland�rma
     *
     * @access puplic
     * @param   string
     */
    function image_edit_thumb_jpe_g($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);
     	if ($width_org > $this->thumb_pic_width && $height_org >  $this->thumb_pic_height) {
        $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
        $thumb = imagecreatetruecolor($this->thumb_pic_width, $this->thumb_pic_height);
        $source2 = imagecreatefromjpeg($source_target);
        imagecopyresampled($thumb, $source2, 0, 0, 0, 0, $this->thumb_pic_width, $this->thumb_pic_height, $width_, $height_);
        imagejpeg($thumb, $this->thumb_pic_dir.'/'.$suffix_name);
   }
	else 
	{  $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
	copy($this->upload_dir.'/'.$this->new_file_name, $this->thumb_pic_dir.'/'.$suffix_name);}
	}
    
    /**
     *k���k resim yap gif turu yeniden boyutland�rma
     *
     * @access puplic
     * @param   string
     */
    function image_edit_thumb_gif($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);
     	if ($width_org > $this->thumb_pic_width && $height_org >  $this->thumb_pic_height) {
        $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
        $thumb = imagecreatetruecolor($this->thumb_pic_width, $this->thumb_pic_height);
        $source2 = imagecreatefromgif($source_target);
        imagecopyresampled($thumb, $source2, 0, 0, 0, 0, $this->thumb_pic_width, $this->thumb_pic_height, $width_, $height_);
        imagegif($thumb, $this->thumb_pic_dir.'/'.$suffix_name);
   }
	else 
	{  $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
	copy($this->upload_dir.'/'.$this->new_file_name, $this->thumb_pic_dir.'/'.$suffix_name);}
	}
    
    /**
     *k���k resim yap png turu yeniden boyutland�rma
     *
     * @access puplic
     * @param   string
     */
    function image_edit_thumb_png($source_target) {
        $width_ = $this->pic_width;
        $height_ = $this->pic_height;
        list($width_org, $height_org) = getimagesize($source_target);
     	if ($width_org > $this->thumb_pic_width && $height_org >  $this->thumb_pic_height) {
        $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
        $thumb = imagecreatetruecolor($this->thumb_pic_width, $this->thumb_pic_height);
        $source2 = imagecreatefrompng($source_target);
        imagecopyresampled($thumb, $source2, 0, 0, 0, 0, $this->thumb_pic_width, $this->thumb_pic_height, $width_, $height_);
        imagepng($thumb, $this->thumb_pic_dir.'/'.$suffix_name);
   }
	else 
	{  $suffix_name = $this->Suffix($source_target, $this->thumb_pic_extension);
	copy($this->upload_dir.'/'.$this->new_file_name, $this->thumb_pic_dir.'/'.$suffix_name);}
	}
    
    /**
     *t�m degerleri kb cinsine �evir
     *
     * @access puplic
     * @param   string  $size_type_file dosya turu degeri ornek =MB
     * @param  integer value dosya boyutu
     * @return	integer
     */
    function all2kbytes($value, $size_type_file) {
    
        switch ($size_type_file) {
            case 'B':
                $values = $value;
                break;
            case 'KB':
                $values = $value * 1024;
                break;
            case 'MB':
                $values = $value * 1024 * 1024;
                break;
            /*case 'GB':
             $values=$value*1024*1024*1024;
             */
        }
        //return $values = round($value);//byte
        $values = round($values / 1024); //kb
        return $values = round(($values * 1024), 2);//reapat byte tekrar byter
        // return $values=round($values / 1024 / 1024);//mb
        // return  $values=$values / 1024 / 1024 / 1024;//gb
        
    }
    /**
     *boyutlar� kar��la�t�r�r
     *
     * @access puplic
     * @param   string  $file dosya ad�
     * @param  integer $size dosya boyutu
     * @param  integer $file_size dosya boyutu
     * @return	integer
     */
    function size_compare($size, $file_size, $file) {
        if ($size > $file_size) {
            $this->error .= '6:'.$file.' boyutlar cok buyuk';
            
        }
    }
    
    /**
     *boyutlar� kontrol eden yer
     *resimlere bakar ve dosyalar, ��nk� resimlere farkl� boyut verdik bu yuzden 2 li kontrl var
     *
     * @access puplic
     * @return	boolean
     */
    function size_find() {
        if (!$this->error) {
            $mime_types_picture = array('image/pjpeg', 'image/jpeg', 'image/gif', 'image/png', 'image/x-png');
            
            for ($i = 0; $i < count($this->files['tmp_name']); $i++) {
                if (in_array($this->files['type'][$i], $mime_types_picture)) {
                
                    $file_size_pic = $this->all2kbytes($this->picture_size, $this->pic_size_type);
                    
                    $this->size_compare($this->files['size'][$i], $file_size_pic, $this->files['name'][$i]);
                    
                } else {
                    $file_size = $this->all2kbytes($this->size_files, $this->size_type_file);
                    $this->size_compare($this->files['size'][$i], $file_size, $this->files['name'][$i]);
                }
            }
        }
    }
    
    /**	 
     * gd eklentisi yuklumu kontrol et
     * bir resimin, ger�ekten resim olup olmad���no kontrol eder
     *
     *
     * @access  puplic
     */
    function image_control() {
        $mime_types_picture = array('image/pjpeg', 'image/jpeg', 'image/gif', 'image/png', 'image/x-png');
        
        for ($i = 0; $i < count($this->files['tmp_name']); $i++) {
            if (in_array($this->files['type'][$i], $mime_types_picture)) {

            
                if (extension_loaded('gd') && !imagecreatefromstring(file_get_contents($this->files['tmp_name'][$i])))
                
                    $this->error .= '7:'.$this->files['name'][$i].' gercek bir resim dosyas� de�il ';
                    
                elseif (!getimagesize($this->files['tmp_name'][$i]))
                    $this->error .= '7:'.$this->files['name'][$i].' gercek bir resim dosyas� de�il ';
                    
            }
        }
    }

    
    /**	 
     * bir dosyan�n , uzant�s�n�n uyumlu olup olmad���n� kontrol eder
     *
     * @access  puplic
     * @param  array
     */
    function is_file_extension($mime_types) {
    
        //for i�inde her dosya adetince dongu yap�l�r
        for ($i = 0; $i < count($this->files['tmp_name']); $i++) {
            //file_extension fonkyonu ile her dosyn�n uzant�s� bulunur
            //in array ile mimme i�inde varm� kontrol edilir
            if (!in_array($this->file_extension($this->files['name'][$i]), $mime_types))
                //echo "t�r hata ".$this->files['type'][$i];
                $this->error .= '8:'.$this->files['name'][$i].' <li> isimli dosya, uyumsuz dosya tipi nedeniyle y�klenmedi!</li>';
        }
    }

    
    /**
     *raporlar
     *
     * @access puplic
     */
    function result_report() {
        if (isset($this->error)) {
            //echo '<ul>';
            echo $this->error;
            //echo '</ul>';
        }
        if ($this->uploaded == true) {
            // echo '<ul>';
            echo $this->info;
            // echo '</ul>';
        }
    }

    /**
     * ilk tan�mlama de�erleri
     * @param string $_prefix
     * @param string $suffix_
     * @param string $size_type_file
     * @param string $size_files
     */
    function first_values($_prefix, $suffix_, $size_type_file, $size_files) {
        $this->suffix_=$suffix_;
        $this->_prefix=$_prefix;
        $this->size_type_file = $size_type_file;
        $this->size_files = $size_files;
    }

    /**
     * resim editleme degerleri d��ardan vermek i�in 
     * 
     * @param boolean $picture_edit
     * @param integer $pic_width
     * @param integer $pic_height
     * @param string $pic_size_type
     * @param string $picture_size
     */
    function picture_edit_values ($picture_edit, $pic_width, $pic_height, $pic_size_type, $picture_size) {
        $this->picture_edit = $picture_edit;
        $this->pic_width = $pic_width;
        $this->pic_height = $pic_height;
        $this->pic_size_type = $pic_size_type;
        $this->picture_size = $picture_size;
    }
    
	/**
	 * resimin �nizlme hali degerleri d��ardan vermek i�in 
	 * 
	 * @param boolean $thumb_picture
	 * @param string $thumb_pic_dir
	 * @param integer $pic_width
	 * @param integer $pic_height
	 * @param string $thumb_pic_extension
	 */
    function picture_edit_thumb_values($thumb_picture, $thumb_pic_dir, $thumb_pic_width, $thumb_pic_height,$thumb_pic_extension) {
        $this->thumb_picture = $thumb_picture;
        $this->thumb_pic_dir = $thumb_pic_dir;
       $this->thumb_pic_width = $thumb_pic_width;
	     $this->thumb_pic_height = $thumb_pic_height;
        $this->thumb_pic_extension =$thumb_pic_extension;
    }

    
    /**
     *�al��t�r�c� fonksiyon, her�ey ilk �al��maya burdan ba�lar
     *
     * @access puplic
     * @param   array  $files
     * @param  string $upload_dir dosya yolu
     * @param  array $mime_types dosya turleri
     */
    function uploader_set($files, $upload_dir, $mime_types) {
    
        $this->upload_dir($upload_dir);
        $this->files($files);
        $this->is_file_extension($mime_types);
        $this->size_find();
        $this->image_control();//belki uste
        $this->upload();
        
    }
}
error_reporting($error_report_old);//eski

?>
