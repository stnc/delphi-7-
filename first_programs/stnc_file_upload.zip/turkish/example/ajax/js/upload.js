/*yazann=Z�lk�f K���k�zer  
geli�tiren= Selman Tun� -selmantunc.com-*/
$(document).ready(function(){
 
    $('#file_upload_form').bind('submit', form_submit);
    
    function form_submit(){
       
        $('#mesaj').empty();
       
        $('#file_upload_form').attr('target', 'upload_target');
   
        $('<img/>').attr('src', 'loadingAnimation.gif').appendTo($('#mesaj'));
      
        $('#upload_target').bind('load', file_loaded);
    }
    
  
    function file_loaded(){
        
        var message = $('#upload_target').contents().find('body').text();
     
        $('img').remove();
       
        var deger = message.substring(message.indexOf(':') + 1, message.length);//kalan� ver
        var message = (message.substr(0, 1));
       
        switch (message) {
            case '1':
			$('#mesaj').addClass("ekleniyor");
                $('#mesaj').html('i�lem tamam kay�t yap�ld�' + '<br>' + deger + '<br>');

		

		                break;
            case '2':
			//$('#mesaj').addClass("ekleniyor");
                $('#mesaj').html('resim dizini izni yok' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '3':
			//$('#mesaj').addClass("ekleniyor");
                $('#mesaj').html('yazma izni yok' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '4':
                $('#mesaj').html('kucuk resim dizini yok ' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '5':
                $('#mesaj').html('kucuk resim dizini yazma izni yok ' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '6':
                $('#mesaj').html('dosya �ok buyuk' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '7':
                $('#mesaj').html('Bu dosya gercek bir resim dosyas� de�il l�tfen d�zeltin,sald�r� ama�l� dosya olabilir' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '8':
                $('#mesaj').html('uyumsuz uzant� turu' + '<br>' + deger + '<br>').css('color', 'green');
                break;
            case '9':
			$('#mesaj').addClass("ekleniyor");
                //$('#kat').html('' + '<br>' + deger + '<br>').css('color', 'green');
				      $('#mesaj').html('' + '<br>' + deger + '<br>').css('color', 'green');//katorig se� uyar�s�****
                break;
        }
        
    }
});

