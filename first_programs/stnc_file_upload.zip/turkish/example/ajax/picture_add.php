<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-9">
        <meta name="Author" content="Stnc Web Hizmetleri-info@stncweb.net-Selman Tunc">        
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/forms.css">
        <link rel="stylesheet" type="text/css" href="css/grid.css">
        <script src="js/jquery-1.3.2.min.js" type="text/javascript"></script>
	      
      </head>
<body>
 
 
  <script src="js/upload.js" type="text/javascript"> </script>
   <div id="mesaj"></div>
        <form method="POST" enctype="multipart/form-data" id="file_upload_form" name="aktar" action="ajax/picture_add.php">
            <table width="419" height="29" border="0">
                <tr>
                    <th colspan="2" scope="col" class="table_baslik">
                        Resim Ekleme
                        B&ouml;l&uuml;m&uuml;
                    </th>
                </tr>
                <?php 
               
                $max_no_img = 1;
                
                for ($res = 1; $res <= $max_no_img; $res++) { 
                    
                ?>
                <tr class="ikili_table_renk<?php echo $res?>">
                    <td width="92">
                        Resim
                    </td>
                    <td width="447">
                        <input type="file" id="resim_<?php echo $res?>" size="%50" name="file[]" />
                    </td>
                    <?php } ?>
                </tr>
         
       
           
            </table>
			<input class="submit" type="submit" name="submit" value="Kaydet" class="kaydet">
             
		    <iframe id="upload_target" name="upload_target" src="" style="display:none;">
            </iframe>
        </form>
		</body></html>