<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
<title>Untitled Document</title>
<style  type="text/css">
.block-2-table {
    border: 1px solid #DDDDDD;
    border-collapse: collapse;
    color: #404040;
    font-size: 12px;
    margin: 5px;
    width: 300px;
}
.text-right {
    text-align: right;
}.progress {
    background: -moz-linear-gradient(center top , #CCCCCC, #E9E9E9) repeat scroll 0 0 transparent;
    border: 1px solid #CCCCCC;
    border-radius: 4px 4px 4px 4px;
    box-shadow: 0 1px 0 #FFFFFF;
    display: block;
    height: 22px;
    margin: 4px 0;
    padding: 0;
    position: relative;
    width: 140px;
}
.progress span {
    border-radius: 3px 3px 3px 3px;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.5) inset;
    display: block;
    height: 20px;
    margin: 0;
    padding: 0;
    text-align: center;
    width: 0;
}
.progress span b {
    color: #FFFFFF;
    line-height: 20px;
    padding-left: 2px;
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.5);
}
.progress-blue span {
    background: -moz-linear-gradient(center top , #00ADEE 10%, #0078A5 90%) repeat scroll 0 0 transparent;
    border: 1px solid #0078A5;
}
.progress-green span {
    background: -moz-linear-gradient(center top , #8FC857 10%, #5C9425 90%) repeat scroll 0 0 transparent;
    border: 1px solid #5C9425;
}
</style>
<script  type="text/javascript" src="jquery-1.7.js"></script>
<!--//ie7 i�in json2-->
<script type="text/javascript" src="json2.js"></script>
<script type="text/javascript" >
  $(document).ready(function(){
bos_data_cek('resim_hesapla.php');
});


function bos_data_cek(page){
    $.ajax({
        type: "POST",
        url: page,
		cache: false,
             success: function(msg){  	
	  var obj = JSON.parse(msg);
  total_host=  obj.post[0].total_host;
   pluspercent=  obj.post[0].pluspercent;
  return1=obj.post[0].result;	

  
   //$('#add_picture li#'+id ).addClass('loading');
   if (return1=='ok')   {
   
 $("#progress1 span b").html(pluspercent );
		 $("#progress1 span").css({"width": pluspercent});
		  $("#total_host").html(total_host );
		 
}
else {
alert ('Hesaplama Hatas�');  
}}})
;}

</script>
</head>

<body>
<table border="0" class="block-2-table">
            <colgroup>
                <col width="120">
                <col width="140">
                <col width="40">
            </colgroup>
            <tbody>
                <tr>
                <td class="text-right">Toplam Alan </td>
                <td>
                <div class="progress progress-green" id="progress1"><span style="width: 17%;"><b>17%</b></span></div>
                </td>
                <td class="text-left"><span id="total_host">250/192</span></td>
                </tr>
            </tbody>
        </table>
</body>
</html>