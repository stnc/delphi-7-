﻿<?php


$uzanti='jpg';

 function ext($text)  { 
    $text = strtolower(pathinfo($text, PATHINFO_EXTENSION));
    return $text;  }
 
	function convertBytes($value)
    {
        if (is_numeric($value)) {
            return $value;
        }
        else
        {
            $value_length = strlen($value);
            $qty = substr($value, 0, $value_length - 1);
            $unit = strtolower(substr($value, $value_length - 1));
            switch ($unit)
            {
                case 'k':
                    $qty *= 1024;
                    break;
                case 'm':
                    $qty *= 1048576;
                    break;
                case 'g':
                    $qty *= 1073741824;
                    break;
            }
            return $qty;
        }
    }
	
	
	 function roundSize($filesize, $phpConfig = false)
    {
     
    
        if ($filesize < 0) {
            $filesize = sprintf("%u", $filesize);
        }
        if ($filesize >= 1073741824) {
            $filesize = round($filesize / 1073741824 * 100) / 100 . ($phpConfig ? "G" : " G" . $size_unit);
        }
        elseif ($filesize >= 1048576) {
            $filesize = round($filesize / 1048576 * 100) / 100 . ($phpConfig ? "M" : " M" . $size_unit);
        }
        elseif ($filesize >= 1024) {
            $filesize = round($filesize / 1024 * 100) / 100 . ($phpConfig ? "K" : " K" . $size_unit);
        }
        else {
            $filesize = $filesize . " " . $size_unit;
        }
        if ($filesize == 0) {
            $filesize = "-";
        }
        return $filesize;
    }



	
	
function percent($a,$b){
$sonuc=$a/$b;
return $sonuc=round($sonuc*100);
}


function folder_($dizin,$uzanti){
if ($handle = opendir("$dizin") or die ("Dizin acilamadi!")) {

    while (false !== ($file = readdir($handle))) {
    $filetype = ext($file);
        if(is_file($dizin."/".$file) && $filetype == "$uzanti") 
		{ 	
 $deger=convertBytes(filesize( $dizin.'/'.$file)) ;
 $boyutlar[] =$deger;
  }  } //while end
$e=array_sum($boyutlar);


 $e=roundSize($e);
$dilim = explode(" ", $e);//eğer k cinsi yani kilo byat değeri gelirse onun için 
$bak=$dilim[1]; 

if ($bak=='K'){$e='0 M';}

$e= substr($e, 0, -2);   
return $e2=floor( number_format($e))+1;
closedir($handle);
}
}


 

 $a1=folder_('resimler',$uzanti);


 
 
$total=250;

$remaining=$total - $a1;
$pluspercent1=percent($remaining,$total);//toplam yüzde boş alan 
//echo '<br/>';
 $pluspercent=100-percent($remaining,$total);//yüzde dolu alan 
$total1='250'.'/'. $remaining;



	echo '{"post":[ {
	"total_host":"'.$total1.'", 
 
	"pluspercent":"'.$pluspercent.'%'.'",        
	"result":"ok" }]}';
?>