<?php
define("BASEDIR", dirname(__FILE__));
 date_default_timezone_set('Europe/Istanbul');
include_once (BASEDIR."/lib/class.ez_sql_core.php");

include_once (BASEDIR."/lib/class.ez_sql_mysql.php");

	define("DB_USER", "root");			
	define("DB_PASSWORD", "depdde");			
	define("DB_NAME", "yeni_yonetim");	
	define("DB_HOST", "localhost");  



$db = new ezSQL_mysql(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
/* 
define('LNG_NAME', 'latin5');

define('LNG_OPTIONS', 'latin5_turkish_ci'); */
define('LNG_NAME', 'utf8');
define('LNG_OPTIONS', 'utf8_general_ci');	
$db->query("set SESSION character_set_client = ".LNG_NAME."");

$db->query("set SESSION character_set_connection = ".LNG_NAME."");

$db->query("SET CHARACTER SET ".LNG_NAME."");

$db->query("SET COLLATION_CONNECTION = '".LNG_OPTIONS."'");

?>