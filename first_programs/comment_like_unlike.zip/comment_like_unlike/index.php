<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="script.js" type="text/javascript"></script>
<link rel="stylesheet" href="comment.css" type="text/css" media="all" />



</head>

<body>
<?php 
include_once ('lib/class.ez_sql_core.php');
include_once ('lib/class.ez_sql_mysql.php');
require_once ('connect.php');


include 'lib/class.kgPager.ajax.php';

$vid_id=1;
$total_records = $db->get_var("SELECT count(vcom.id) from comments as vcom, comments_likes as vcomlike where vcom.status_=1 and  vcomlike.comment_id=vcom.id ");
$kgPagerOBJ = & new kgPager();
$scroll_page = 10; // paging
$per_page = 3; // page total
$git_sayfa = 'ajax_video_yorumlar.php';
$current_page = $_GET['page'];
$pager_url = 1;// $id;
$inactive_page_tag = 'class="current_page"';
$previous_page_text = '&lt; Önceki Sayfa';
$next_page_text = 'Sonraki Sayfa &gt;';
$first_page_text = '&lt;&lt;';
$last_page_text = '&gt;&gt;';
$pager_url_last = 1;//$id;
$kgPagerOBJ->pager_set($pager_url, $total_records, $scroll_page, $per_page, $current_page, $inactive_page_tag, $previous_page_text, $next_page_text, $first_page_text, $last_page_text, $pager_url_last, $git_sayfa);

$first_page = $kgPagerOBJ->first_page;
$previous_page = $kgPagerOBJ->previous_page;
$page_links = $kgPagerOBJ->page_links;
$next_page = $kgPagerOBJ->next_page;
$last_page = $kgPagerOBJ->last_page;
echo 'toplam yorum: '.$total_records;

?>

<div id="comment_block">


<?php 


echo '<div class="comment_pager">';

 echo $first_page;
 echo $previous_page;
 echo $page_links;
 echo $next_page;
 echo $last_page;

echo '</div><!--comment pager-->';

//yorumlar


/*  $sql = "SELECT id,name_surname,comments,add_date from vimhub_video_comments
where status_=1 and video_id=1 limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page; */

/*

 echo $sql = "SELECT vcomlike.id as comlike_id, vcom.name_surname,vcom.comments,vcom.add_date,likes,unlikes 
from vimhub_video_comments as vcom, vimhub_video_comments_likes as vcomlike where vcom.status_=1 and 
vcom.video_id=".$vid_id." and vcom.video_id=vcomlike.video_id and vcomlike.comment_id=vcom.id  limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page;

*/
 $sql = "SELECT vcomlike.id as comlike_id, vcom.name_surname,vcom.comments,vcom.add_date,likes,unlikes 
from comments as vcom, comments_likes as vcomlike where vcom.status_=1 and  vcomlike.comment_id=vcom.id  limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page;
$comments = $db->get_results($sql, ARRAY_A);
if ($comments != '') {
    foreach ($comments as $comment) {
    $com_id = $comment['comlike_id'];
	 $com_like = $comment['likes'];
	  $com_unlike = $comment['unlikes'];
       $ad = $comment['name_surname'];
      
    
        $zaman_once = $comment['add_date'];
        $yorum = $comment['comments'];
   

?>

<div class="comment_box_v1">
<div class="profil_img">
<img src="images/comment_BlackTheme.png" alt="prof" />
</div><!--//profil_img-->
<ul>
<li class="user_info">
<img width="16" height="16" alt="user" src="images/user.png" />
<strong><?php echo $ad; ?></strong>
</li>
<li class="mini_date">
<img width="12" height="14" alt="date" src="images/calendar.png" /> <?php echo $zaman_once ; ?>
</li>
<li>
<img width="16" height="16" alt="yorum" src="images/comment.png" />  <?php echo  $yorum; ?></li>
<li class="mini_date">
<span>Yorumu oyla&nbsp;&nbsp;&nbsp; 
 


<a href="javascript:void(0);" onclick="like(<?php echo $com_id; ?>,'ajax_comment_like.php')" 
class="comment_vote"  name="com_like_vidlike">
     
            <img border="0" align="absmiddle" style="padding:0 0 3px 0;" src="images/yorum_agree.gif">
            
            </a><span id="wh_comlike<?php echo $com_id; ?>"><?php echo $com_like; ?></span>
            
<a href="javascript:void(0);" onclick="unlike(<?php echo $com_id; ?>,'ajax_comment_unlike.php')"
 class="comment_vote"  name="com_unlike_vidunlike">
          
            <img border="0" align="absmiddle" style="padding:0 0 3px 0;" src="images/yorum_disagree.gif">
           </a> <span id="wh_comunlike<?php echo $com_id; ?>"><?php echo $com_unlike; ?></span>
          
         
       </span>

</li>
</ul>
</div><!--//comment_box_v1-->
 <?
	}
}
?>
<div class="comment_pager">
<?php 
 echo $first_page;
 echo $previous_page;
 echo $page_links;
 echo $next_page;
 echo $last_page;
 ?>
</div><!--comment pager-->
</div><!--//comment_block-->
</body>
</html>