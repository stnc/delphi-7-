﻿

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_surname` varchar(255) DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `comments` text,
  `ip_adress` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `add_date` datetime DEFAULT '0000-00-00 00:00:00',
  `edit_date` datetime DEFAULT NULL,
  `status_` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin5 ROW_FORMAT=DYNAMIC;

#
# Dumping data for table comments
#

INSERT INTO `comments` VALUES (1,'hakan alper','dd@fff.com','süper video',NULL,'2011-05-01',NULL,1);
INSERT INTO `comments` VALUES (5,'denen ozle','dd@fff.com','denem yorumu ',NULL,'2011-07-01',NULL,1);
INSERT INTO `comments` VALUES (6,'ahme alpi','dd@fff.com','iyi güzel',NULL,'2011-02-01',NULL,1);
INSERT INTO `comments` VALUES (7,'denen ozle1','dd@fff.com','iyi güzel',NULL,'2011-06-01',NULL,1);
INSERT INTO `comments` VALUES (8,'de2','dd@fff.com','iyi güzel2Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (9,'de3',NULL,'iyi güzel3',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (10,'de4',NULL,'iyi güzel5',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (11,'de5',NULL,'iyi güzel6',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (12,'de6',NULL,'iyi güzel7',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (13,'de7',NULL,'iyi güzel8',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (14,'de8',NULL,'iyi güzel8990',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (15,'de9',NULL,'iyi güzelds fdsdsfg',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (16,'de10',NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi',NULL,'0000-00-00 00:00:00',NULL,1);
INSERT INTO `comments` VALUES (17,'de11','dd@fff.com','iyi güzelvd dfgdfgdf dfg',NULL,'0000-00-00 00:00:00',NULL,1);

#
# Source for table comments_likes
#

CREATE TABLE `comments_likes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT NULL,
  `likes` bigint(11) DEFAULT '0',
  `unlikes` bigint(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

#
# Dumping data for table comments_likes
#

INSERT INTO `comments_likes` VALUES (1,1,2,1);
INSERT INTO `comments_likes` VALUES (2,2,0,0);
INSERT INTO `comments_likes` VALUES (3,3,0,0);
INSERT INTO `comments_likes` VALUES (4,4,0,0);
INSERT INTO `comments_likes` VALUES (5,5,2,1);
INSERT INTO `comments_likes` VALUES (6,6,0,1);
INSERT INTO `comments_likes` VALUES (7,7,0,1);
INSERT INTO `comments_likes` VALUES (8,8,0,1);

#
# Source for table comments_likes_ipadress
#

CREATE TABLE `comments_likes_ipadress` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT NULL,
  `ip_addres` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Dumping data for table comments_likes_ipadress
#

