<?php


include_once ('../lib/class.ez_sql_core.php');
include_once ('../lib/class.ez_sql_mysql.php');
require_once ('../connect.php');


include '../lib/class.kgPager.ajax.php';



$total_records = $db->get_var("SELECT count(vcom.id) from comments as vcom, comments_likes as vcomlike where vcom.status_=1 and 
vcomlike.comment_id=vcom.id ");

 $kgPagerOBJ = & new kgPager();
$scroll_page = 10; // paging
$per_page = 3; // page total
				$git_sayfa='ajax_video_yorumlar.php';
                $current_page = $_GET['page']; 
                $pager_url = $id; 
                $inactive_page_tag = 'class="current_page"'; 
                $previous_page_text = '&lt; Önceki Sayfa'; 
                $next_page_text = 'Sonraki Sayfa &gt;'; 
                $first_page_text = '&lt;&lt;'; 
                $last_page_text = '&gt;&gt;'; 
                $pager_url_last =$id; 
$kgPagerOBJ->pager_set($pager_url, $total_records, $scroll_page, $per_page, $current_page,
 $inactive_page_tag, $previous_page_text, $next_page_text, $first_page_text, $last_page_text, $pager_url_last,$git_sayfa);
                
echo ' <div class="comment_pager">';
echo $kgPagerOBJ->first_page;
echo $kgPagerOBJ->previous_page;
echo $kgPagerOBJ->page_links;
echo $kgPagerOBJ->next_page;
echo $kgPagerOBJ->last_page;
echo '</div>';


//yorumlar
 $sql = "SELECT vcomlike.id as comlike_id, vcom.name_surname,vcom.comments,vcom.add_date,likes,unlikes 
from comments as vcom, comments_likes as vcomlike where vcom.status_=1 and 
 vcomlike.comment_id=vcom.id limit  ".$kgPagerOBJ->start.", ".$kgPagerOBJ->per_page;
$comments = $db->get_results($sql, ARRAY_A);
if ($comments != '') {
    foreach ($comments as $comment) {
    
       $com_id = $comment['comlike_id'];
	 $com_like = $comment['likes'];
	  $com_unlike = $comment['unlikes'];
	  $ad = $comment['name_surname'];
       // $tar = $comment['tarih'];
      
        $zaman_once = $comment['add_date'];
        $yorum = $comment['comments'];
   

?>

<div class="comment_box_v1">
<div class="profil_img">
<img src="images/comment_BlackTheme.png" alt="prof" />
</div><!--//profil_img-->
<ul>
<li class="user_info">
<img width="16" height="16" alt="user" src="images/user.png" />
<strong><?php echo $ad; ?></strong>
</li>
<li class="mini_date">
<img width="12" height="14" alt="date" src="images/calendar.png" /> <?php echo $zaman_once ; ?>
</li>
<li>
<img width="16" height="16" alt="yorum" src="images/comment.png" />  <?php echo  $yorum; ?></li>
<li class="mini_date">
<span>Yorumu oyla&nbsp;&nbsp;&nbsp; 
 


<a href="javascript:void(0);" onclick="like(<?php echo $com_id; ?>,'ajax_comment_like.php')" 
class="comment_vote"  name="com_like_vidlike">
     
            <img border="0" align="absmiddle" style="padding:0 0 3px 0;" src="images/yorum_agree.gif">
            
            </a><span id="wh_comlike<?php echo $com_id; ?>"><?php echo $com_like; ?></span>
            
<a href="javascript:void(0);" onclick="unlike(<?php echo $com_id; ?>,'ajax_comment_unlike.php')"
 class="comment_vote"  name="com_unlike_vidunlike">
          
            <img border="0" align="absmiddle" style="padding:0 0 3px 0;" src="images/yorum_disagree.gif">
           </a> <span id="wh_comunlike<?php echo $com_id; ?>"><?php echo $com_unlike; ?></span>
          
         
       </span>

</li>
</ul>
</div><!--//comment_box_v1-->
    <?
	}
}

else 			
{
echo 'Henuz Hiç yorum girilmemiş';
}
echo ' <div class="comment_pager">';
echo $kgPagerOBJ->first_page;
echo $kgPagerOBJ->previous_page;
echo $kgPagerOBJ->page_links;
echo $kgPagerOBJ->next_page;
echo $kgPagerOBJ->last_page;
echo '</div>';

?>