<?php



include_once ('../lib/class.ez_sql_core.php');
include_once ('../lib/class.ez_sql_mysql.php');
require_once ('../connect.php');


$ip=$_SERVER['REMOTE_ADDR'];

if($_SERVER["REQUEST_METHOD"] == "POST"){
if($_POST['id'])
{
if ( isset ($_POST['id']) && intval($_POST['id'])){
$id = $_POST['id'];
//ip doğrulama
$ip_sql="select ip_addres from comments_likes_ipadress where comment_id='$id' and ip_addres='$ip'";
$db->query($ip_sql);
$count= $db->get_var("select count(ip_addres) from comments_likes_ipadress where comment_id='$id' and ip_addres='$ip' ");
if($count==0)
{
$sql = "update comments_likes set likes=likes+1 where comment_id='$id'";
$db->query($sql);
$sql_in = "insert into comments_likes_ipadress (id,comment_id,ip_addres) values (NULL,'$id','$ip')";
$db->query($sql_in);
echo "<script>alert('Puan verdiğiniz için teşekkür ederiz');</script>";
}
else
{
echo "<script>alert('Üzgünüm Daha Önce Puan Verdiniz');</script>";
}
 $result="select likes from comments_likes where comment_id='$id'";

echo $toplam= $db->get_var($result);

}}
else {echo "<script>alert('ooovvv my god bir sorun var ');</script>";}
}
?>