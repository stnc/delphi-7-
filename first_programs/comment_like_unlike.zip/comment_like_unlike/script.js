
 
function paging(page,sayfa){
$.ajax({
type: 'GET',
 url: 'ajax/'+sayfa,
 data: 'page='+page,
success: function(sonuc) {
$('#comment_block').html(sonuc);
}
});
return false;
}

function like(id,sayfa){
$.ajax({
type: 'POST',
 url: 'ajax/'+sayfa,
 data: 'id='+id,
 success: function(html_){
 $('span#wh_comlike'+id).html(html_);
}
				
});
return false;
}

function unlike(id,sayfa){
$.ajax({
type: 'POST',
 url: 'ajax/'+sayfa,
 data: 'id='+id,
 success: function(html_){
 $('span#wh_comunlike'+id).html(html_);
}
				
});
return false;
}



