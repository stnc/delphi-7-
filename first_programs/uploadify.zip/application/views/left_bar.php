<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu accordion_mnu collapsible">
						<li class="nav-header hidden-tablet">Anasayfa</li>
						
						<li><a class="ajax-link" href="<?php echo base_url();?>index.php/admin/dashboard/">
						<i class="icon-home"></i><span class="hidden-tablet"> Ana Menü</span></a></li>
						
						
						

     
     
      	  <li>
		<a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i>Haberler</a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/news/">Haberler </a></li>
		<li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/news/add">Haber Ekle</a></li>
      </ul>
      </li>	
      
      
            	  <li>
		<a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i> İndirilebilir Dosyalar </a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/download/"> İndirilebilir Dosyalar  </a></li>
		<li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/download/add">Dosya Ekle</a></li>
		<li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/download/list_cat">Dosya Kategorileri</a></li>
		<li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/download/add_cat">Dosya Kategorisi ekle</a></li>
      </ul>
      </li>	
      
      
        <li>
		<a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i>Etkinlikler</a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/events/">Etkinlik Takvimi </a></li>
     <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/etkinlik_katilimcilar/">Etkinlik Talep Formları</a></li>
      </ul>
      </li>	
      
      
              <li>
		<a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i>Site Ayarları</a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/administrator/">Yöneticiler</a></li>
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/administrator/add">Yönetici ekle</a></li>
      </ul>
      </li>	
      
      
  
      
                 <li>
		<a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i>Mesajlar</a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php echo base_url();?>index.php/admin/contact/">Mesajlar</a></li>
      </ul>
      </li>	
				
			
						
				<!--		<li><a class="ajax-link" href="<?php //echo base_url();?>index.php/admin/personal/">
						<i class="icon-eye-open"></i><span class="hidden-tablet">Personel Bilgileri</span></a></li>
						
						
			 <li>
			 <a href="#"><span class="hidden-tablet"></span>  <i class="icon-eye-open"></i>Diğer Eklenecek</a>
      <ul class="acitem">
        <li><a class="a-link-gray feddle" href="<?php //echo base_url();?>index.php/admin/personal/add">ornek</a></li>
         <li><a class="a-link-gray feddle" href="<?php //echo base_url();?>index.php/admin/personal/add">ornek</a></li>
         <li><a class="a-link-gray feddle" href="<?php //echo base_url();?>index.php/admin/personal/add">ornek</a></li>
         <li><a class="a-link-gray feddle" href="<?php //echo base_url();?>index.php/admin/personal/add">ornek</a></li>
      </ul>
    </li>	
						
								<li><a class="ajax-link" href="<?php //echo base_url();?>index.php/admin/personal/add">
						<i class="icon-plus"></i><span class="hidden-tablet">Personel Ekle</span></a></li>
						
						
		
						
						<li><a class="ajax-link" href="<?php //echo base_url();?>index.php/admin/company/">
						<i class="icon-list-alt"></i><span class="hidden-tablet">Şirketler</span></a></li>
						-->	
		
					</ul>
					<label id="for-is-ajax" class="hidden-tablet" for="is-ajax"><input id="is-ajax" type="checkbox"> Aktif Menü</label>
				</div><!--/.well -->
			</div><!--/span-->