<footer>
			<p class="pull-left">&copy; <a href="http://selmantunc.com" target="_blank">selmantunc.com</a> 2013</p>
			<p class="pull-right">developer: <a href="http://selmantunc.com">selmantunc.com</a></p>
		</footer>
		
	</div><!--/.fluid-container-->



</body>
</html>
