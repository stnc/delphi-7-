<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
	<title>codeigniter uploadify example</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="selmantunc.com ">
	<meta name="author" content="STNCWEB">

	<!-- The styles altın id="bs-css"  -->
	<link  href="<?php echo base_url();?>panel/css/bootstrap-cerulean.css" rel="stylesheet">
	<style type="text/css">
	  body {
		padding-bottom: 40px;
	  }
	  .sidebar-nav {
		padding: 9px 0;
	  }
	</style>
	<link href="<?php echo base_url();?>panel/css/bootstrap-responsive.css" rel="stylesheet">
	<link href="<?php echo base_url();?>panel/css/charisma-app.css" rel="stylesheet">
	<link href="<?php echo base_url();?>panel/css/jquery-ui-1.8.21.custom.css" rel="stylesheet">





	<link href='<?php echo base_url();?>panel/css/uploadify.css' rel='stylesheet'>
<!-- jQuery -->
	<script src="<?php echo base_url();?>panel/js/jquery-1.7.2.min.js"></script>
	<!-- jQuery UI -->
	<script src="<?php echo base_url();?>panel/js/jquery-ui-1.8.21.custom.min.js"></script>


	<!-- accordion library (optional, not used in demo) -->
	<script src="<?php echo base_url();?>panel/js/bootstrap-collapse.js"></script>

	<link href="<?php echo base_url();?>panel/css/colorbox.css" rel="stylesheet">
	<script src="<?php echo base_url();?>panel/js/jquery.colorbox.min.js"></script>

	<!-- select or dropdown enhancer -->
	<script src="<?php echo base_url();?>panel/js/jquery.chosen.min.js"></script>




	
<script src="<?php echo base_url()?>panel/js/jquery.uploadify-3.1.min.js"></script>
	

	
	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<!-- The fav icon -->
	<link rel="shortcut icon" href="<?php echo base_url();?>img/favicon.ico">
	
	</head>
	
	
