<?php
$this->load ->view('header.php');

?>


<body>
		<!-- topbar starts -->

	<!-- topbar ends -->
		<div class="container-fluid">
		<div class="row-fluid">
				
			<!-- left menu starts -->
			
				<!-- left menu ends -->
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Uyarı!</h4>
					<p> <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> lütfen etkinleştirin.</p>
				</div>
			</noscript>
			
			<div id="content" class="span10">
			<!-- content starts -->
			

			
			
			<div class="row-fluid sortable">
		  <div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-th"></i>picture add</h2>
						<div class="box-icon">
							
						</div>
					</div>
					
							
							
					<div class="box-content">
					
	
 <fieldset>
				
		
								


							  
							 
							
								
								
									<div class="control-group">
								<label class="control-label">Resim Yükleme 	</label>										
								<div class="controls">
									<input data-no-uniform="true" type="file" id="userfile" name="userfile" />	
					<!-- <button name="" type="button" id="upload-file" class="btn btn-large btn-primary" >Upload</button>   -->
								  
						
			   <span id="status-message"> </span>							
   <div id="status-message2"> Resimler: </div>
                            <div id="description">
<ul id="add_picture">
</ul>
</div>
</div></div>
								
								
	
							       
						
						
						</div>
						
					
	
				
							
						  </fieldset>
						  
			
						
					</div>
				</div><!--/span--><!--/span--><!--/span-->
			</div><!--/row--><!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				



<script type="text/javascript">
    $(document).ready(function () {


    	
        var base_url = '<?php echo base_url(); ?>';
  var site_url = '<?php echo site_url(); ?>';
  


        $('#userfile').uploadify({

        
            'auto':true,
            'swf': base_url + 'panel/uploadify.swf',
            'uploader': site_url + 'upload/news_upload',
            'cancelImg': base_url + 'front/uploadify-cancel.png',
            'fileTypeExts':'*.jpg;*.bmp;*.png;*.tif',
            'fileTypeDesc':'Image Files (.jpg,.bmp,.png,.tif)',
           // 'fileSizeLimit':'2MB',
            'fileObjName':'userfile',
            'buttonText':'Resim Yükleme',
            'multi':false,
            'removeCompleted':true,
	            'buttonText':'Dosya seçiniz',
			  'queueSizeLimit' : 1,
			  'simUploadLimit' : 1,

			'onUploadSuccess': function(file, data, response) {

			//	$("#formsubmit").val('LÜtfen Bekleyiniz');
			//	$('#form-horizontal').submit(function() {return false;	});

				if (response==true){
					
				     var insert_obj = jQuery.parseJSON( data);
				     var files_=  insert_obj.post[0].result;
				     var pic=insert_obj.post[0].report;

				//	 $("#picture_").val(pic);//bunun metodunu silmem lazım update için düzeltilerbilr
				  	//$("#msg_box_warning").hide();
				  	insert_file(pic,site_url+'news/insert_file'); 
				  	}}

        });
    
    });


    function insert_file(value,page){
        var base_url = '<?php echo base_url(); ?>';
        var site_url = '<?php echo site_url(); ?>';
    	 $.ajax({
             type: "GET",
             url: page,
     		  data: "name=" + value,
     		cache: false,
             success: function(msg){  	
            

                 var obj =obj = jQuery.parseJSON(msg);
                 result1= obj.post[0].report;
                 return1=	  obj.post[0].result;

              
         if ( return1 =='ok')   {



     		var a_href=' <a class="cboxElement" href="'+base_url+'uploads/files/'+value+'"> <img id="imgid'+result1+'" height="90" class="upoad-pictures" src="'+base_url+'uploads/files/'+value+'"  />  </a> ';



	   var a_href_delete='<a href="javascript:void(0);" style="color:#000;font-size:12px" onclick="file_delete(\''+result1+'\',\''+site_url+'news/file_delete\')">  <img src="'+base_url+'/front/images/picture-icon-set/delete.png" />Sil</a> ';



			 $('<li id="lipic'+result1+'"></li>').appendTo('#add_picture').html(
'</div>  '+a_href+' <div class="degis">'+ a_href_delete +'').addClass('success');
		      
             
			 alert( value + ' isimli dosya başarı ile yüklendi '  );
     }         
     else {
alert (  result1);
     }
     }}) 
    }
      




    function file_delete(id,page){
        $.ajax({
            type: "GET",
            url: page,
    		  data: "id=" + encodeURIComponent(id),
    		cache: false,
            success: function(msg){  	
    //silinde fadeout gelsin uyarı sonra classı sil 
       $('#add_picture li#'+id ).addClass('loading');
        if (msg=='ok')   {
    	 $('#add_picture li#lipic'+id ).removeClass('loading');
    $('#add_picture li#lipic'+id  ).remove();
    }
    else {
      alert ("silme sırasında bir hata oluştu  ,lütfen bu hata kodu 'HATA KODU :NDel1' ile  yöneticinize başvurunuz");
        
   
    }}})
    ;}




    
</script>
									
	<?php $this->load ->view('footer.php'); ?>
