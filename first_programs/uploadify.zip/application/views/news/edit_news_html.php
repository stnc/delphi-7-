<?php
$this->load ->view('admin/header.php');
$this->load ->helper('datetime');
$pathname = 'news';
?>


<body>
		<!-- topbar starts -->
<?php $this->load ->view('admin/top_bar.php'); ?>
	<!-- topbar ends -->
		<div class="container-fluid">
		<div class="row-fluid">
				
			<!-- left menu starts -->
			<?php $this->load ->view('admin/left_bar.php'); ?>
				<!-- left menu ends -->
				
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Uyarı!</h4>
					<p> <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> lütfen etkinleştirin.</p>
				</div>
			</noscript>
			
			<div id="content" class="span10">
			<!-- content starts -->
			
			

			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Anasayfa</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="/index.php/admin/news">Haberler</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="/index.php/admin/news/add">Haber düzenleme</a>
					</li>
				</ul>
			</div>
			
			<?php if (validation_errors()) { ?>			
			<div class="box-content alerts">
						
						<div class="alert alert-error">
							<button data-dismiss="alert" class="close" type="button">×</button>
							<h4 class="alert-heading">Uyarı!!</h4>
							<p>Bilgileri ekleme sırasında bazı hatalar oluştu lütfen bilgilerinizi tekrar kontrol ediniz. 
							<br/>
								<?php echo $err; ?>
							</p>
						</div>
					</div>
			<?php }
if ($msg != '' or $this->input->get('success') == 'ok') {
?>			
			<div class="box-content alerts">
						
						<div class="alert alert-success">
							<button data-dismiss="alert" class="close" type="button">×</button>
							<h4 class="alert-heading">İşlem Başarı ile kaydedildi</h4>
							<p><?php echo $msg; ?> </p>
						</div>
					</div>
			<?php } ?>
			
			
			<div class="row-fluid sortable">
		  <div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-th"></i> Haber Düzenleme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						</div>
					</div>
					
							
							
					<div class="box-content">
					  <?php if ($news) {
	foreach ($news as $row) :
		//if (validation_errors())			
		echo form_open_multipart('admin/'.$pathname.'/update/'.$row->id.'?success=ok', array('id' => 'form-horizontal', 'class' => 'form-horizontal'));
		// else echo form_open_multipart( 'admin/dashboard' ,array('id' => 'form-horizontal','class'=>'form-horizontal' ));
?>
				
				<div class="form-actions" style="padding-left: 20px;">						 
				<?php echo form_submit(array("name" => "formsubmit", "class" => "btn btn-primary", "value" => 'Bilgileri Kaydet')) ?>
							</div>	
						
						 
		
							  
								<div class="control-group<?php echo  form_error('title') != '' ? ' error' : ''; ?>">
								<label class="control-label" for="title">Haber Başlık </label>
								<div class="controls">
<input class="input-xlarge focused" id="title" name="title" type="text" style="width: 586px;" value="<?php echo set_value('title', $row -> title); ?>"/>
				<span class="help-inline"> <?php echo form_error('title') ?></span>
								</div>
							  </div>
							  
					<div class="control-group<?php echo form_error('spot') != '' ? ' error' : ''; ?>">
					<label class="control-label" for="spot">Haber spot</label>
							  <div class="controls">
			<textarea style="width: 589px; height: 83px;"  id="spot" name="spot" rows="3"><?php echo set_value('title', $row->title); ?></textarea>
								 <span class="help-inline"> <?php echo form_error('spot') ?></span>
							  </div>
							</div>
							
							
							
								 <div class="control-group">
								<label class="control-label">Görünüm Tipi</label>
								<div class="controls">
								  <label class="checkbox inline">
					<div class="checker" id="uniform-inlineCheckbox1"><span class="">
					<input type="checkbox" value="1" 
					 <?php if ($row -> flash == 1)
											echo 'checked="checked"';
									?>
					
					id="flash" name="flash" style="opacity: 0;"></span></div> Flash Haber
								  </label>
								  
								</div>
							  </div>
							  
							
							  
							  
							   <div class="control-group<?php  echo form_error('type') != '' ? ' error' : ''; ?>">
								<label class="control-label" for="type"> Bölümler </label>
								<div class="controls">
									  <select  id="type" name="type">
									  <option value="">Seçiniz</option> 				  
				<?php $a = 0;
		$sss = array("Taysad Haberleri", "Basından Haberler", "Üyelerden Haberler", "Duyurular", "Taysad Dergi");
		if ($this->input->post('formsubmit')) {

			foreach ($sss as $s) {
				$a++;
				if ($this->input->post('type') == $a)
					echo '<option selected="selected" value="'.$a.'">'.$s.'</option>';
				else
					echo '<option  value="'.$a.'">'.$s.'</option>';
			}
		} else {
			foreach ($sss as $s) {
				$a++;
				if ($row->type == $a)
					echo '<option selected="selected" value="'.$a.'">'.$s.'</option>';
				else
					echo '<option  value="'.$a.'">'.$s.'</option>';
			}
		}
?>
			</select>
					<span class="help-inline"> <?php echo form_error('type') ?></span> 
								</div>
							  </div>
							  
							  
							  
						<div class="control-group<?php echo  form_error('source') != '' ? ' error' : ''; ?>">
								<label class="control-label" for="source">Haber Kaynağı </label>
								<div class="controls">
	<input class="input-xlarge focused" id="source" name="source" type="text" value="<?php echo set_value('source', $row ->source); ?>"/>
				<span class="help-inline"> <?php echo form_error('source') ?></span>
								</div>
							  </div>
							  
							  
							  
							  <div class="control-group<?php  echo form_error('duration_date') != '' ? ' error' : ''; ?>">
							  <label class="control-label" for="duration_date">
				Yayından Kaldırılma Tarihi</label>
							  <div class="controls">
<input type="text" class="input-xlarge datepicker" id="duration_date" name="duration_date" value="<?php echo set_value('duration_date', tr_date( $row -> duration_date)); ?>"/>
								 <span class="help-inline"> <?php echo form_error('duration_date') ?></span>
							  </div>
							</div>
							
							
						<div class="control-group<?php echo form_error('language') != '' ? ' error' : ''; ?>">
								<label class="control-label">Dil Seçimi	burası db de 0 diye geçiyor 											
								
								<span>
<a data-rel="tooltip" href="#" data-original-title=" Bu sayfanın ingilizce mi türkçe mi hangi dilde yayında olacağını belirtir ">?</a>
								</span>
								</label>
								<div class="controls">
								<label class="radio">
							    <div class="radio" id="uniform-optionsRadios1">
							   <span class="">
			   <input type="radio"   <?php if ($row -> language == 1)	echo 'checked="checked"'; ?>  	   
			   value="1" id="optionsRadios1" name="language" style="opacity: 0;"></span></div>Türkçe  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<div class="radio" id="uniform-optionsRadios2"><span class="checked">
		<input type="radio"   <?php if ($row -> language == 2)
											echo 'checked="checked"';
									?>   id="optionsRadios2" name="language" style="opacity: 0;"></span></div>
								İngilizce
								  </label>
								  <span class="help-inline"> <?php echo form_error('language') ?></span>
								</div></div>
								
								
												<div class="control-group">
								<label class="control-label">Resim Yükleme 	</label>										
								<div class="controls">
									<input data-no-uniform="true" type="file" id="userfile" name="userfile" />	
					<!-- <button name="" type="button" id="upload-file" class="btn btn-large btn-primary" >Upload</button>   -->
								      <a href="#" class="btn btn-danger" data-rel="popover" 
								      data-content="
								          Resim yükleye tıklatıkdan sonra  birden fazla resim seçerek yükleme yapabilirsiniz.
										En fazla 5 MB büyüklüğünde resim seçiniz 
										Tek seferde yükleyebileceğiniz en fazla resim sayısı 1 adettir.
										" title="ipucu">ipucu</a>
			   <span id="status-message"> </span>							
   <div id="status-message2"> Resimler: </div>
<div id="description">
<ul id="add_picture">
<?php if ($row->picture != '') { ?>
<li id="lipic<?php echo $row -> id ;?>" class="success">  

<img height="90" src="<?php echo base_url() ;?>uploads/haberler/<?php echo $row -> picture ;?>"
 class="upoad-pictures" id="imgid<?php echo $row -> id ;?>">
 
<a onclick="picture_delete(<?php echo $row -> id ;?> ,'<?php echo site_url() ;?>admin/news/picture_delete')" href="javascript:void(0);"> 
<img src="<?php echo base_url() ;?>/front/images/picture-icon-set/delete.png"></a>  
<?php } ?>
</div>
    </li></ul>
</div>                 
                         
                         
                         
</div>
							       
							<div class="control-group">
							  <label class="control-label" for="details">Haber Detayı</label>
							  <div class="controls">
<textarea class="cleditor" name="details" id="details" rows="3"><?php echo set_value('details', $row->details); ?></textarea>
						
								
							  </div>
							</div>
						
						</div>
						
						<div class="form-actions">
							  <input type="submit" class="btn btn-primary" name="formsubmit" value="Bilgileri kaydet">
							 
							</div>
					
						  <?php endforeach;
}
echo form_close(); //selman
?>  
						
					</div>
				</div><!--/span--><!--/span--><!--/span-->
			</div><!--/row--><!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

		<div class="modal hide fade" id="myModal">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h3>Ayarlar</h3>
			</div>
			<div class="modal-body">
				<p>deneme amaçlıdır</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn" data-dismiss="modal">Kapat</a>
				<a href="#" class="btn btn-primary">Kaydet</a>
			</div>
		</div>



		<script type="text/javascript">
		    $(document).ready(function () {

		    	
		        var base_url = '<?php echo base_url(); ?>';
		  var site_url = '<?php echo site_url(); ?>';
		  


		        $('#userfile').uploadify({

		        
		            'auto':true,
		            'swf': base_url + 'front/uploadify.swf',
		            'uploader': site_url + 'upload/news_upload',
		            'cancelImg': base_url + 'front/uploadify-cancel.png',
		            'fileTypeExts':'*.jpg;*.bmp;*.png;*.tif',
		            'fileTypeDesc':'Image Files (.jpg,.bmp,.png,.tif)',
		           // 'fileSizeLimit':'2MB',
		            'fileObjName':'userfile',
		            'buttonText':'Resim Yükleme',
		            'multi':true,
		            'removeCompleted':true,
			            'buttonText':'Dosya seçiniz',
					  'queueSizeLimit' : 1,
					  'simUploadLimit' : 1,

					'onUploadSuccess': function(file, data, response) {

						$("#formsubmit").val('LÜtfen Bekleyiniz');
					//	$('#form-horizontal').submit(function() {return false;	});

						
						if (response==true){
							
						     var insert_obj = JSON.parse( data);
						     files_=  insert_obj.post[0].result;
						      return_insert=insert_obj.post[0].report;
						    
						  	var pic=return_insert;
							 $("#picture_").val(pic);
						  	$("#msg_box_warning").hide();


						  	
						 // 	$("#formsubmit").val('Kaydet');

						  	var a_href=' <a href="javascript:void(0);" onclick="tb_show(\'Resim Önizleme\',\'inc/page_picture_previews.php?id='+pic+'&TB_iframe=true&height=400&width=500\')"> <img id="imgid'+pic+'" height="90" class="upoad-pictures" src="'+base_url+'uploads/haberler/'+pic+'"  />  </a> ';
						  	
						  	var a_picture_rotate_left=  	'<a href="javascript:void(0);" onclick="picture_rotate ('+pic+',\''+files_+'\',\'ajax/page_picture_rotate.php\');"><img  src="'+base_url+'/front/images/picture-icon-set/right.png" /></a> <a href="javascript:void(0);" onclick="picture_rotate('+pic+',\''+files_+'\',\'ajax/page_picture_rotate.php\');"><img  src="'+base_url+'/front/images/picture-icon-set/right.png" /></a>';

							var a_picture_rotate_right=  	'<a href="javascript:void(0);" onclick="picture_rotate ('+pic+',\''+files_+'\',\'ajax/page_picture_rotate.php\');"><img  src="'+base_url+'/front/images/picture-icon-set/left.png" /></a> <a href="javascript:void(0);" onclick="picture_rotate('+pic+',\''+files_+'\',\'ajax/page_picture_rotate.php\');"><img  src="'+base_url+'/front/images/picture-icon-set/left.png" /></a>';

							
					   var a_href_delete='<a href="javascript:void(0);" onclick="picture_delete('+pic+',\'ajax/page_picture_delete.php\')">  <img src="'+base_url+'/front/images/picture-icon-set/delete.png" /></a> ';

 
						var a_href_edit='<a href="javascript:void(0);" onclick="tb_show(\'Resim Düzenle\',\'inc/page_picture_update.php?id='+pic+'&TB_iframe=true&height=400&width=500\')"> <img  src="'+base_url+'/front/images/picture-icon-set/edit.png" /></a>';  	

						  	 
		  				 $('<li id="lipic'+pic+'"></li>').appendTo('#add_picture').html(
		  					    '</div>  '+a_href+' <div class="degis">'+a_picture_rotate_left+a_picture_rotate_left + a_href_delete + a_href_edit+'').addClass('success');
						      
		  				showResultPage (data,'ajax/page_picture_insert.php',
		  						'uploads/',	'includes/page_picture_previews.php','ajax/page_picture_rotate.php','ajax/page_picture_delete.php','includes/page_picture_update.php');

		  						

						}},
				
		        //http://www.uploadify.com/documentation/uploadify/onuploadsuccess/
				 'onUploadSuccess' : function(file, data, response) {
			            alert(  file.name + ' isimli dosya başarı ile yüklendi '  );
			        } 

	        });
		    });
		        

			
	    function picture_delete(id,page){
	        $.ajax({
	            type: "GET",
	            url: page,
	    		  data: "id=" + encodeURIComponent(id),
	    		cache: false,
	            success: function(msg){  	
	    //silinde fadeout gelsin uyarı sonra classı sil 
	       $('#add_picture li#'+id ).addClass('loading');
	        if (msg=='ok')   {
	    	 $('#add_picture li#lipic'+id ).removeClass('loading');
	    $('#add_picture li#lipic'+id  ).remove();
	    }
	    else {
	    	$("#msg_box_warning").hide();
	    $("#msg_box_warning").show();
	      $("#msg_box_typewarning").html("Hata oluştu " );
	    }}})
	    ;}

		</script>
		
	<?php $this->load ->view('admin/footer.php'); ?>
	
	

