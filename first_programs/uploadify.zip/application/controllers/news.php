<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class News extends CI_Controller {

	public function __Construct() {
		parent::__construct();

	}

	public function index() {


		$this->load ->view('news/news_html', $data);

	}

	public function add() {
	
	
		
		
		$this->load ->view('news/add_news_html');

	}

	//ajax ile calışır
	public function insert_file() {


			echo '{"post":[{"report":"tamam", "result":"ok" }]}';
		
	}

	public function file_delete() {
		$pic =$this->input->get('id', TRUE);
					@unlink(FCPATH.'/uploads/files/'.$pic);
						echo "ok";
	}

}
?>
