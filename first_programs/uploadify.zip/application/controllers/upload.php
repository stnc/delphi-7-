<?php if (!defined('BASEPATH'))
	exit('No direct script access allowed');

/**
 * @property CI_Upload $upload
 */

class Upload extends CI_Controller {

	public $view_data = array();
	private $upload_config;

	function __construct() {
		parent::__construct();
	}

	public function news_upload() {
		$this->load->library('upload');
		$image_upload_folder = FCPATH.'/uploads/files';

		$this->upload_config = array(
			'upload_path' => $image_upload_folder,
			'allowed_types' => 'png|jpg|jpeg',
			'max_size' => 5048,
			'remove_space' => TRUE,
			//'encrypt_name' => TRUE,
		);

		$this->upload->initialize($this->upload_config);

		if (!$this->upload->do_upload()) {
			$upload_error = $this->upload->display_errors();
			echo '{"post":[{"report":"'.$upload_error.'","result":"error" }]}';
		} else {
			$file_info = $this->upload->data();
			echo '{"post":[{"report":"'.$file_info['file_name'].'", "result":"ok" }]}';
		}

	}
	
	

}

/*   echo json_encode($upload_error);
 echo '<pre>';   echo '</pre>';
echo json_encode($file_info);
echo print_r( $file_info) ;

*/
