<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class General_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_news = "news";

	private $res = '';

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}



	//duyurular
	function list_notification_news($limit = NULL) {
		$pr = $this->db->dbprefix('news');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$query = $this->db ->query('select id,title from '.$pr.' where record_status<>0 and type=4  order by id desc '.$limit.'');
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	//id ye göre seçilen il gelir 
	function get_il($type) {
		$this->db ->select('IL_ADI,IL_ID');
		$this->db ->where('IL_ID', $type, '=');
		$this->db ->order_by('IL_ADI', 'ASC');
		$query = $this->db ->get('il');
		return $query->result();
	}
	

	
	//etkinlikler
	function list_activity($limit = NULL) {
		$pr = $this->db->dbprefix('activity');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$query = $this->db ->query('select * from '.$pr.' where record_status<>0   order by id desc '.$limit.'');
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	
	//bilgi bankası
	function list_file_category($limit = NULL) {
		$pr = $this->db->dbprefix('file_category');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$query = $this->db ->query('select * from '.$pr.'   order by category_explanation asc '.$limit.'');
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

}
?>
