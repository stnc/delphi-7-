<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Etkinlikler_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_news = "news";

	function __construct() {

		parent::__construct();
		//$this->load ->helper('datetime');
		}
		

	function list_activity ($limit = NULL) {
		$pr = $this->db->dbprefix('activity_calendar');
		$limit = $limit == NULL ? '' : $limit;
		
		
		$this->db ->select('activity.* , activity_calendar.* ');
		$this->db ->from('activity');
		$this->db->join('activity_calendar', 'activity_calendar.activity_id=activity.id');
		$this->db ->where('activity.record_status',  2);
		
		/*$this->db ->where('activity.etkinlik_tip_id <>',  1);
		$this->db ->where('activity.etkinlik_tip_id <>', 2);
		$this->db ->where('activity.etkinlik_tip_id <>',  3);*/

		$this->db->order_by('activity.id', 'desc');

		$this->db->limit($limit);
	
			$query = $this->db ->get();	
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	function list_activity_cat ($limit = NULL) {
		$pr = $this->db->dbprefix('download_files');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$id = (int)$this->uri ->segment(3);
		
		$s=' select *  from  '.$pr.' where language_ = 0 AND fk_file_cat= '.$id.'
				order by add_date desc '.$limit.'';
		
		
		$query = $this->db ->query($s);
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	

	//dosya gelsin 
	function get_activity($news_id=NULL) {
			//$news_id = (int) $this->input ->post('id');
		$news_id = $news_id!=NULL ? $news_id :  (int)$this->uri ->segment(2);//kullandım
		
		$query = $this->db->get_where('upload_files', array('rec_id' => $news_id));
	
		if ($query->num_rows() > 0) {
			$this->db ->select('download_files.* , upload_files.* ');
			$this->db ->from('download_files');
			$this->db->join('upload_files', 'download_files.id=rec_id');
			$this->db ->where('rec_id', $news_id, '=');
			$this->db ->where('language_',  0);
			
			/*
			SELECT  FROM prj_download_files
			inner join prj_upload_files on prj_download_files.id=rec_id
			WHERE language_ = 0 AND rec_id = 426 ;*/

			$query = $this->db ->get();
			return ($query->result());
		} else {
			return false;
		}}
		

}

	

?>
