<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Iletisim_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_news = "news";

	function __construct() {

		parent::__construct();
		//$this->load ->helper('datetime');
		}

		//haberler
	function add_contact() {
		
		//ip güvenlikleri vss
	$this->email = $this->input->post('email', TRUE);
	$this->name_lastname = $this->input->post('name_lastname', TRUE);
	$this->email=  $this->input->post('email', TRUE);
	$this->subject= $this->input->post('subject', TRUE);
	$this->message= $this->input->post('message', TRUE);

    $ok = $this->db ->insert('news', $this);

		if ($ok) {
		return true;
		}


	}

	}
	

?>
