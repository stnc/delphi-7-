<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class News_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_news = "news";

	function __construct() {

		parent::__construct();
		//$this->load ->helper('datetime');
		}

		//haberler
	function list_news($limit = NULL,$costum=NULL) {
		$pr = $this->db->dbprefix('news');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$costum =$costum == NULL ? '' : $costum;
		$s='select * from '.$pr.' where record_status=4 '.$costum.'  order by id desc '.$limit.'';
		$query = $this->db ->query($s);
	
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	


	/*
	//order sıralaması değişirse diye koydum yedekdir kullanımda degıl
	function last_news() {
		$pr = $this->db->dbprefix('news');
		$limit = 'limit 1';
		$query = $this->db ->query('select * from '.$pr.' where record_status<>0  order by id desc '.$limit.'');
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}*/

	
	
	//haber gelsin
	function get_news($news_id=NULL) {
			//$news_id = (int) $this->input ->post('id');
		$news_id = $news_id!=NULL ? $news_id :  (int)$this->uri ->segment(2);//kullandım
		$query = $this->db->get_where('news', array('id' => $news_id));
	
		if ($query->num_rows() > 0) {
			$this->db ->select('news.*');
			$this->db ->where('news.id', $news_id, '=');

			$this->db ->from('news');

			$query = $this->db ->get();
			return ($query->result());
		} else {
			return false;
		}}
		

}
	/*

	//haberi okur
	function get_news() {
		//$news_id = $this->db->escape($this->uri->segment(4));
		$news_id = (int) $this->input ->post('id');
		$news_id = ($news_id) ? $news_id : $this->uri ->segment(4);
		//$query = $this->db->query("SELECT * FROM news WHERE id = ".$news_id." ");return $query->result();

		//$this->db->select('news.*,  section.id as  sid ');
		$this->db ->select('news.*');
		$this->db ->where('news.id', $news_id, '=');
		$this->db ->from('news');
		//$this->db->join('section', 'section.id = news.section_id');
		//$this->db->join('town', 'town.id = news.i_town');
		$query = $this->db ->get();
		return ($query->result());

	}
	*/
	

?>
