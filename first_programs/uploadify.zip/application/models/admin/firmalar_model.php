<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firmalar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_firmalar($perpage, $segment, $search = NULL) {
		$this->db ->select('firmalar.*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		if ($search != NULL) {
			$this->db->like('firma_adi', $search);
		}
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();

		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	function total_count_search($search = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$s = $search != NULL ? " AND `firma_adi` LIKE '%".$search."%'" : '';
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0 $s");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database  ekleme
	function add_firmalar() {

		$data = array(
			"firma_adi" => $this->input ->post("firma_adi", TRUE),
			"firma_kodu" => $this->input ->post("firma_kodu", TRUE),
			"temsilci_ismi" => $this->input ->post("temsilci_ismi", TRUE),
			"firma_eposta" => $this->input ->post("firma_eposta", TRUE),
			"temsilci_email" => $this->input ->post("temsilci_email", TRUE),
			"firma_websitesi" => $this->input ->post("firma_websitesi", TRUE),
			"kurulus_yili" => $this->input ->post("kurulus_yili", TRUE),
			"firma_yapisi" => $this->input ->post("firma_yapisi", TRUE),
			"aile_calisan_sayisi" => $this->input ->post("aile_calisan_sayisi", TRUE),
			"bagli_olunan_holding_varmi" => $this->input ->post("bagli_olunan_holding_varmi", TRUE),
			"bagli_olunan_holding_adi" => $this->input ->post("bagli_olunan_holding_adi", TRUE),
			"taysad_ortak_satin_alma_calismasi" => $this->input ->post("taysad_ortak_satin_alma_calismasi", TRUE),
			"alt_sirket1" => $this->input ->post("alt_sirket1", TRUE),
			"alt_sirket2" => $this->input ->post("alt_sirket2", TRUE),
			"ortak_sirket" => $this->input ->post("ortak_sirket", TRUE),
				"beklentiler" => $this->input ->post("beklentiler", TRUE),
				
			"diger_sirket1" => $this->input ->post("diger_sirket1", TRUE),
			"eklenme_tarihi" => date("Y-n-j H:i:s")
		);

		$ok = $this->db ->insert('firmalar', $data);

		//echo $this->db ->last_query();

		if ($ok) {
			$res = $this->db ->insert_id();
			$b = array(
				'firma_id' => $res,

			);
			$this->db ->insert('firma_calisanlar', $b);

			$b2 = array(
				'firma_id' => $res,
			);
			$this->db ->insert('firma_calisan_egitimleri', $b2);

			$b3 = array(
				'firma_id' => $res,
			);
			$this->db ->insert('firma_fabrika_bilgileri', $b3);

			$b4 = array(
				'firma_id' => $res,
			);
			$this->db ->insert('firma_test_laboratuar', $b4);

			$b5 = array(
				'firma_id' => $res,
			);
			$this->db ->insert('firma_arge', $b5);

			return $res;
		}

	}

	function update_firmalar() {

		$id = $this->uri ->segment(4);

		$data = array(
			"firma_adi" => $this->input ->post("firma_adi", TRUE),
			"firma_kodu" => $this->input ->post("firma_kodu", TRUE),
			"temsilci_ismi" => $this->input ->post("temsilci_ismi", TRUE),
			"firma_eposta" => $this->input ->post("firma_eposta", TRUE),
			"temsilci_email" => $this->input ->post("temsilci_email", TRUE),
			"firma_websitesi" => $this->input ->post("firma_websitesi", TRUE),
			"kurulus_yili" => $this->input ->post("kurulus_yili", TRUE),
			"aile_calisan_sayisi" => $this->input ->post("aile_calisan_sayisi", TRUE),
			"bagli_olunan_holding_varmi" => $this->input ->post("bagli_olunan_holding_varmi", TRUE),
			"alt_sirket1" => $this->input ->post("alt_sirket1", TRUE),
			"alt_sirket2" => $this->input ->post("alt_sirket2", TRUE),
			"ortak_sirket" => $this->input ->post("ortak_sirket", TRUE),
			"diger_sirket1" => $this->input ->post("diger_sirket1", TRUE),
			"diger_sirket1_turu" => $this->input ->post("diger_sirket1_turu", TRUE),
			"diger_sirket1_taysad_uyelik" => $this->input ->post("diger_sirket1_taysad_uyelik", TRUE),
				"taysad_ortak_satin_alma_calismasi" => $this->input ->post("taysad_ortak_satin_alma_calismasi", TRUE),
			"kurucu8" => $this->input ->post("kurucu8", TRUE),
			"kurucu7" => $this->input ->post("kurucu7", TRUE),
			"kurucu6" => $this->input ->post("kurucu6", TRUE),
			"kurucu5" => $this->input ->post("kurucu5", TRUE),
			"kurucu4" => $this->input ->post("kurucu4", TRUE),
			"kurucu3" => $this->input ->post("kurucu3", TRUE),
			"kurucu2" => $this->input ->post("kurucu2", TRUE),
			"kurucu1" => $this->input ->post("kurucu1", TRUE),
				"beklentiler" => $this->input ->post("beklentiler", TRUE),
			"firma_yapisi" => $this->input ->post("firma_yapisi", TRUE)
		);
		$this->db ->where('id', $id);
		$this->db ->update('firmalar', $data);

	}

	function get_firmalar($firmalar_id) {
		/*$firmalar_id = $this->db->escape($this->uri->segment(4));
		 $this->db->select('firmalar.*,  section.id as  sid ');*/
		$this->db ->select('firmalar.*');
		$this->db ->where('firmalar.id', $firmalar_id, '=');
		$this->db ->from('firmalar');
		$query = $this->db ->get();
		return ($query->result());
	}

	function delete() {
		$count = $this->db ->get('firmalar');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('firmalar', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

}
?>
