<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_calisanlar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}
/*
	function list_firmalar($perpage, $segment, $search = NULL) {
		$this->db ->select('fir.id as id,firma_adi,muhendis,maviyaka,beyazyaka,toplam, SUM(toplam+muhendis+maviyaka+beyazyaka) as genel_toplam');
		$this->db ->where('record_status <>', '0');

		if ($search != NULL) {
			$this->db->like('firma_adi', $search);
		}

		$this->db ->from('firma_calisanlar as calisan');
		$this->db ->join('firmalar as fir', 'fir.id=calisan.firma_id');
		$this->db ->group_by('firma_adi');

		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();

		if ($query->num_rows() > 0) {
			return $query->result();

		} else {
			return false;
		}
	}

	function total_count_search($search) {

		$this->db ->select('count(toplam) as toplam');
		$this->db ->where('record_status <>', '0');

		if ($search != NULL) {
			$this->db->like('firma_adi', $search);
		}
		$this->db ->from('firma_calisanlar as calisan');
		$this->db ->join('firmalar as fir', 'fir.id=calisan.firma_id');

		$query = $this->db ->get();

		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}
	
	
		//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$this->db ->select('count(toplam) as toplam');
		$this->db ->where('record_status <>', '0');
	
		$this->db ->from('firma_calisanlar as calisan');
		$this->db ->join('firmalar as fir', 'fir.id=calisan.firma_id');
	
		$query = $this->db ->get();
		$sonuc = $query->result();
	
		return $sonuc[0]->toplam;
	}
	

	function delete() {
		$count = $this->db ->get('firmalar');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('firmalar', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}
	
	

	function get_firmalar($firmalar_id = NULL) {
		$this->db ->select('fir.id as id,firma_adi,muhendis,maviyaka,beyazyaka,toplam');
		$this->db ->from('firma_calisanlar as calisan');
		$this->db ->join('firmalar as fir', 'fir.id=calisan.firma_id');
		$this->db ->where('record_status <>', '0');
		$this->db ->where('fir.id', $firmalar_id, '=');
		$this->db ->group_by('firma_adi');
		$query = $this->db ->get();
		return ($query->result());
	}

	*/
	
	function get_firmalar($firmalar_id = NULL) {
		$this->db ->select(' firma_id as id,muhendis,maviyaka,beyazyaka,toplam');
		$this->db ->from('firma_calisanlar as calisan');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
	    return $query->result();
	
	}


	function firma_ismi($id=NULL) {
	
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	
	

	function update_firmalar() {
		$id = $this->uri ->segment(4);
		$data = array(
			"maviyaka"  =>  $this->input ->post("maviyaka", TRUE),
			"beyazyaka" =>  $this->input ->post("beyazyaka",TRUE),
			"muhendis"  =>  $this->input ->post("muhendis", TRUE)
		);
		$this->db ->where('firma_id', $id);
		$this->db ->update('firma_calisanlar', $data);

	}


}
?>
