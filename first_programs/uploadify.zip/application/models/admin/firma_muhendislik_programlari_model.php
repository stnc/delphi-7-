<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_muhendislik_programlari_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function firma_ismi($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}

	function liste() {
		$this->db ->select('*');
		$this->db ->from('kat_firma_muhendislik_programlari');
		$query = $this->db ->get();
		return $query->result();
	}

	function secili_liste($id) {
		$this->db ->select('program_id');
		$this->db ->from('firma_muhendislik_programlari');
		$this->db ->where('firma_id', $id, '=');
		$query = $this->db ->get();
		//object yapıdan çıkardım inarray olması için kontrolu için yeni bi arrayde grupaladım
		foreach ($query->result() as $db_) {
			$db_den2[] = $db_->program_id;
		}
	}

	function guncelle($id = NULL) {
		$this->db ->where('firma_id', $id);
		$this->db ->delete('firma_muhendislik_programlari');
		$posttan = $this->input->post("belge");
		foreach ($posttan as $p) {
			$data = array(
				"firma_id" => $id,
				"program_id" => $p
			);

			$this->db ->insert('firma_muhendislik_programlari', $data);
		}
	}
}
?>
