<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_yurtdisi_yatirimlar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function firma_ismi($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}

	function liste() {
		$this->db ->select('*');
		$this->db ->from('kat_ulkeler');
		$query = $this->db ->get();
		return $query->result();
	}

	function secili_liste($id) {
		$this->db->select('ulke_id as id');
		$this->db->from('firma_yurtdisi_yatirimlar');
		$this->db->where('firma_id', $id, '=');
		//$this->db ->order_by('ulke_id','desc');
		$query = $this->db ->get();
		//object yapıdan çıkardım inarray olması için kontrolu için yeni bi arrayde grupladım
		foreach ($query->result() as $db_) {
			$db_den2[] = $db_->id;
		}

		if (empty($db_den2)) {
			$db_den2 = NULL;
		} //eğer hiç bişey yoksa null göndersin hata basmasın ekrana

		return $db_den2;
	}

	function update($id = NULL) {
		$this->db->where('firma_id', $id);
		$this->db->delete('firma_yurtdisi_yatirimlar');
		$posttan = $this->input->post("belge");

		foreach ($posttan as $p) {
			$data = array(
				"firma_id" => $id,
				"ulke_id" => $p
			);

			$this->db ->insert('firma_yurtdisi_yatirimlar', $data);
		}

	}

}
?>
