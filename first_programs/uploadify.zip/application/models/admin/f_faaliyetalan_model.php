<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class f_faaliyetalan_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	/**
	 * faaliyet alanına göre firmalar bölümü 
	 * mesela montaj işi yapanlar
	 * 
	 * */
	
	
	//firnmaların listesi 
	function list_firmalar($perpage, $segment) {
		$this->db ->select('firma_adi,firma_eposta,id');
		//$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	//firnmaların listesi
	function list_firmalar_tumu() {
		$this->db ->select('firma_adi,id');
		//$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
	
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	//aramaya göre mesela montaj işi yaoanları verir post değerine göredir
	function aramalist_firmalar($perpage, $segment) {
		
			$flist=$this->input ->post("flist");
			$this->db ->select(' firma_adi, fir.id as id, firma_eposta ');
			$this->db ->from('firmalar as fir');
			$this->db ->join('firmaanafaaliyetalani as fa','fa.firma_id=fir.id');
			$this->db ->join('prj_firmafaaliyetalanlari as fal','fal.id=fa.alan_id');
			$this->db ->where('fa.alan_id', $flist);

		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	
	
	//ismi
	function firma_faaliyetalani_ismi() {	
		$flist=$this->input ->post("flist");
		$pr = $this->db->dbprefix('firmafaaliyetalanlari');
		$query = $this->db->query("SELECT ad FROM ".$pr."  where id=".$flist." ");
		$sonuc = $query->result();
		return $sonuc[0]->ad;
	}
	
	
	

	//yaptıgı faailytetlerin toplanmı 
	function firma_faaliyetalan_toplamlari() {
		$flist=$this->input ->post("flist");
		$this->db ->select('COUNT(*) AS toplam ');
		$this->db ->from('firmalar as fir');
		$this->db ->join('firmaanafaaliyetalani as fa','fa.firma_id=fir.id');
		$this->db ->join('prj_firmafaaliyetalanlari as fal','fal.id=fa.alan_id');
		$this->db ->where('fa.alan_id', $flist);
		$query = $this->db ->get();
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}
	
	//firmaların tüm faaliyet alanlarını getirir 
	function liste_firma_faaliyetalanlari() {
		$this->db ->select('*');
		$this->db ->from('firmafaaliyetalanlari');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		
		} else {
			return false;
		}
	}

	//firmalar toplamı
	function total_count() {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." ");//where record_status <>0
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}
	
	
	
	/* ghangi firma hangi işleri yapıyor 
	 * 
 
	 *    */
	
	//aramaya göre mesela montaj işi yaoanları verir post değerine göredir
	function aramalist_firma_isleri() {
	
		$flist=$this->input ->post("flist");
		$this->db ->select(' fal.ad,firma_id ');
		$this->db ->from('firmalar as fir');
		$this->db ->join('firmaanafaaliyetalani as fa','fa.firma_id=fir.id');
		$this->db ->join('prj_firmafaaliyetalanlari as fal','fal.id=fa.alan_id');
		$this->db ->where('fa.firma_id', $flist);

		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	
	//yaptıgı faailytetlerin toplanmı
	function aramalist_firma_isleri_toplami() {
		$flist=$this->input ->post("flist");
		$this->db ->select('COUNT(*) AS toplam ');
		$this->db ->from('firmalar as fir');
		$this->db ->join('firmaanafaaliyetalani as fa','fa.firma_id=fir.id');
		$this->db ->join('prj_firmafaaliyetalanlari as fal','fal.id=fa.alan_id');
		$this->db ->where('fa.firma_id', $flist);
		$query = $this->db ->get();
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}
	
	//fişrmanın adını verir 
	function firma_ismi() {
		$flist=$this->input ->post("flist");
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$flist." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
//ekle 
	function add_news() {
		$this->title = $this->input ->post("title", TRUE);
		$this->spot = $this->input ->post("spot", TRUE);
		$this->source = $this->input ->post("source", TRUE);
		$this->type = $this->input ->post("type", TRUE);
		$this->flash = $this->input ->post("flash", TRUE);
		$this->picture = $this->input ->post("picture_", TRUE);
		$this->duration_date = tr_date_add($this->input ->post("duration_date", TRUE));
		$this->language = $this->input ->post("language", TRUE);
		$this->details = $this->input ->post("details", TRUE);
		$ok = $this->db ->insert('news', $this);

		if ($ok) {
			$this->res = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;
			}
		return $this->res;
	}




	function update_news() {

		$id = $this->uri ->segment(4);

		// get fileds from post
		$data = array(
			"title" => $this->input ->post("title", TRUE),
			"spot" => $this->input ->post("spot", TRUE),
			"type" => $this->input ->post("type", TRUE),
			"source" => $this->input ->post("source", TRUE),
			"picture" => $this->input ->post("picture_", TRUE),
			"flash" => $this->input ->post("flash", TRUE),
			"duration_date" => $this->input ->post("duration_date", TRUE),
			"language" => $this->input ->post("language", TRUE),
			"details" => $this->input ->post("details", TRUE));
		$this->db ->where('id', $id);
		$this->db ->update('news', $data);

	}

	function get_news($news_id) {
		/*$news_id = $this->db->escape($this->uri->segment(4));
		 $this->db->select('news.*,  section.id as  sid ');*/
		$this->db ->select('news.*');
		$this->db ->where('news.id', $news_id, '=');
		$this->db ->from('news');
		$query = $this->db ->get();
		return ($query->result());
	}



	function delete() {
		$count = $this->db ->get('news');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('news', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}



}
?>
