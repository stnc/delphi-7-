<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Company_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_company = "company";

	private $res = '';

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_company() {
		$query = $this->db ->get('company');
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	// function to insert page in database
	function add_company_model() {

		// assign values from $_POST to class variables

		$this->company_name = $this->input ->post('company_name', TRUE);
		$this->company_webpage > $this->input ->post('company_webpage', TRUE);
		$this->company_email = $this->input ->post('company_email', TRUE);
		$this->company_year_of_establishment = $this->input ->post('company_year_of_establishment', TRUE);

		$this->company_holding_name = $this->input ->post('company_holding_name', TRUE);
		$this->sub_firma1 = $this->input ->post('sub_firma1', TRUE);

		$this->sub_firma2 = $this->input ->post('sub_firma2', TRUE);

		$this->join_firm = $this->input ->post('join_firm', TRUE);

		$this->center_taxVerge = $this->input ->post('center_taxVerge', TRUE);

		$this->center_taxNumber = $this->input ->post('center_taxNumber', TRUE);

		$this->center_ZipCode = $this->input ->post('center_ZipCode', TRUE);

		$this->center_adress = $this->input ->post('center_adress', TRUE);

		$this->center_gsm = $this->input ->post('center_gsm', TRUE);

		$this->center_phone = $this->input ->post('center_phone', TRUE);

		$this->other_taxVerge = $this->input ->post('other_taxVerge', TRUE);

		$this->other_taxNumber = $this->input ->post('other_taxNumber', TRUE);

		$this->other_ZipCode = $this->input ->post('other_ZipCode', TRUE);

		$this->other_adress = $this->input ->post('other_adress', TRUE);

		$this->other_gsm = $this->input ->post('other_gsm', TRUE);

		$this->other_phone = $this->input ->post('other_phone', TRUE);

		$this->center_fax = $this->input ->post('company_page_center_fax', TRUE);

		//$this -> adress_2 = $this -> input -> post('adress_2', TRUE);

		$this->i_city = $this->input ->post('i_city', TRUE);

		$this->i_town = $this->input ->post('i_town', TRUE);

		$this->notes = $this->input ->post('notes2', TRUE);

		$this->notes = $this->input ->post('notes2', TRUE);
		$this->company_structure = $this->input ->post('company_structure', TRUE);
		

		$this->center_city = $this->input ->post('center_city', TRUE);

		$this->center_town = $this->input ->post('center_town', TRUE);
		
		$this->family_member = $this->input ->post('family_member', TRUE);
		
		$this->founder1 = $this->input ->post('founder1', TRUE);
		$this->founder2 = $this->input ->post('founder2', TRUE);
		$this->founder3 = $this->input ->post('founder3', TRUE);
		$this->founder4 = $this->input ->post('founder4', TRUE);
		$this->founder5 = $this->input ->post('founder5', TRUE);
		$this->founder6 = $this->input ->post('founder6', TRUE);
		$this->founder7 = $this->input ->post('founder7', TRUE);
		$this->founder8 = $this->input ->post('founder8', TRUE);
		$this->founder9 = $this->input ->post('founder9', TRUE);
		$this->founder10 = $this->input ->post('founder10', TRUE);


		$ok = $this->db ->insert('company', $this);

		//}

		if ($ok) {

			$this->res = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;

		}

		return $this->res;

	}

	function update_company_model() {

		$id = $this->uri ->segment(4);

		// get fileds from post
		$data = array(

			'company_name' => $this->input ->post('company_name', TRUE),
			'company_webpage' => $this->input ->post('company_webpage', TRUE),
			'company_email' => $this->input ->post('company_email', TRUE),
			'company_year_of_establishment' => $this->input ->post('company_year_of_establishment', TRUE),

			'holding_name' => $this->input ->post('holding_name', TRUE),

			'sub_firma1' => $this->input ->post('sub_firma1', TRUE),
			'sub_firma2' => $this->input ->post('sub_firma2', TRUE),
			'join_firm' => $this->input ->post('join_firm', TRUE),

			'center_ZipCode' => $this->input ->post('center_ZipCode', TRUE),
			'center_adress' => $this->input ->post('center_adress', TRUE),
			'center_city' => $this->input ->post('center_city', TRUE),
			'center_town' => $this->input ->post('center_town', TRUE),

			'center_taxNumber' => $this->input ->post('center_taxNumber', TRUE),

			'center_taxVerge' => $this->input ->post('center_taxVerge', TRUE),

			'center_phone' => $this->input ->post('center_phone', TRUE),
			'center_gsm' => $this->input ->post('center_gsm', TRUE),

			'center_fax' => $this->input ->post('center_fax', TRUE),

			'other_ZipCode' => $this->input ->post('other_ZipCode', TRUE),
			'other_adress' => $this->input ->post('other_adress', TRUE),
			'other_city' => $this->input ->post('other_city', TRUE),
			'other_town' => $this->input ->post('other_town', TRUE),

			'other_taxNumber' => $this->input ->post('other_taxNumber', TRUE),

			'other_taxVerge' => $this->input ->post('other_taxVerge', TRUE),

			'other_phone' => $this->input ->post('other_phone', TRUE),
			'other_gsm' => $this->input ->post('other_gsm', TRUE),

			'other_fax' => $this->input ->post('other_fax', TRUE),

			'i_whyGive' => $this->input ->post('i_whyGive', TRUE),
			'i_GiveDate' => tr_date_add($this->input ->post('i_GiveDate', TRUE)),

			'adress_2' => $this->input ->post('adress_2', TRUE),

			'w_datetime' => tr_date_add($this->input ->post('date01', TRUE)), //işe başlama

			'w_enddate' => tr_date_add($this->input ->post('date02', TRUE)),

			'status_' => $this->input ->post('status_', TRUE),

			'center_taxNumber' => $this->input ->post('center_taxNumber', TRUE),
			
			'company_structure' => $this->input ->post('company_structure', TRUE),
			
			'family_member' => $this->input ->post('family_member', TRUE),
			
			'founder1' => $this->input ->post('founder1', TRUE),
			'founder2' => $this->input ->post('founder2', TRUE),
			'founder3' => $this->input ->post('founder3', TRUE),
			'founder4' => $this->input ->post('founder4', TRUE),
			'founder5' => $this->input ->post('founder5', TRUE),
			'founder6' => $this->input ->post('founder6', TRUE),
			'founder7' => $this->input ->post('founder7', TRUE),
			'founder8' => $this->input ->post('founder8', TRUE),
			'founder9' => $this->input ->post('founder9', TRUE),
			'founder10' => $this->input ->post('founder10', TRUE),
			
		
			'notes' => $this->input ->post('notes2', TRUE));

		$this->db ->where('id', $id);
		$this->db ->update('company', $data);
		//echo $this -> db -> last_query();
		}

	//edit de değerleri okur
	function get_company() {
		//$company_id = $this->db->escape($this->uri->segment(4));
		$company_id = (int) $this->input ->post('id');
		$company_id = ($company_id) ? $company_id : $this->uri ->segment(4);

		//$this->db->select('company.*,  section.id as  sid ');
		$this->db ->select('company.*');
		$this->db ->where('company.id', $company_id, '=');
		$this->db ->from('company');
		//$this->db->join('section', 'section.id = company.section_id');
		//$this->db->join('town', 'town.id = company.i_town');
		$query = $this->db ->get();

		return ($query->result());

	}

	function delete() {

		$count = $this->db ->get('company');

		if ($count->num_rows() == 1) {

			return 1;

		} else {

			if ($this->db ->delete('company', array('id' => $this->uri ->segment(4)))) {

				return 2;

			} else {

				return 3;

			}

		}

	}

}
?>