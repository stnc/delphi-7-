<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Egitmen_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_egitmen = "prj_etkinlik_egitmenler";

	private $res = '';

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
		$this->load->library('pagination');
	}

	function list_egitmen($perpage,$segment) {

		
		$this->db->select("*");
		$this->db->from("etkinlik_egitmenler");
		
		$this->db->limit($perpage,$segment); // sql sorgumuzu limitleyelim
		$query=$this->db->get();
		return $query->result();
	
		
	}
	
	
	function toplam() {
		$pr = $this->db->dbprefix('etkinlik_egitmenler');
		$query=$this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." ");
		$sonuc=$query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database
	function add_egitmen() {
	
		$this->fk_kurum_id = $this->input ->post("fk_kurum_id", TRUE);
$this->egitmen_adsoyad = $this->input ->post("egitmen_adsoyad", TRUE); 
$this->egitmen_detay = $this->input ->post("egitmen_detay", TRUE);
	    $ok = $this -> db -> insert("etkinlik_egitmenler", $this);
				
		if ($ok) {

			$this->res = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;

		}

		return $this->res;

	}

	function update_egitmen() {

		$id = $this->uri ->segment(4);

		// get fileds from post
		$data = array(
				"fk_kurum_id" => $this->input ->post("fk_kurum_id", TRUE),
				"egitmen_detay" => $this->input ->post("egitmen_detay", TRUE),
			"egitmen_adsoyad" => $this->input ->post("egitmen_adsoyad", TRUE)
				
				
		 );

		$this->db ->where('id', $id);
		$this->db ->update('etkinlik_egitmenler', $data);
	//	echo $this -> db -> last_query();
		}

	//edit de değerleri okur
	function get_egitmen() {
		//$egitmen_id = $this->db->escape($this->uri->segment(4));
		$egitmen_id = (int) $this->input ->post('id');
		$egitmen_id = ($egitmen_id) ? $egitmen_id : $this->uri ->segment(4);
		/* $query = $this->db->query("SELECT * FROM egitmen WHERE id = ".$egitmen_id." ");return $query->result();*/

		//$this->db->select('egitmen.*,  section.id as  sid ');
		$this->db ->select('*');
		$this->db ->where('id', $egitmen_id, '=');
		$this->db ->from('etkinlik_egitmenler');
		//$this->db->join('section', 'section.id = egitmen.section_id');
		//$this->db->join('town', 'town.id = egitmen.i_town');
		$query = $this->db ->get();

		return ($query->result());

	}

	function delete() {

		$count = $this->db ->get('etkinlik_egitmenler');

		if ($count->num_rows() == 1) {

			return 1;

		} else {

			$id = $this->uri ->segment(4);

			// get fileds from post
			$data = array("record_status" => 0);

			$this->db ->where('id', $id);
			$ok = $this->db ->update('etkinlik_egitmenler', $data);

			if ($ok) {

				return 2;

			} else {

				return 3;

			}

		}

	}

}
?>
