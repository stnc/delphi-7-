<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Download_model extends CI_Model {

	function __construct() {

		parent::__construct();

	}

	//fronttddan bakarak alacagız
	function list_download($perpage, $segment) {
		$this->db ->select('*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('download_files');
		$this->db->limit($perpage, $segment);
		$this->db ->order_by('id', 'desc');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	//buna benzer bi kaç kod daha vvar parametre eklenecek kısaltılacaklar
	function list_file_category($perpage, $segment) {
		$this->db ->select('*');
		//	$this->db ->where('record_status <>', '0');
		$this->db ->from('file_category');
		$this->db->limit($perpage, $segment);
		$this->db ->order_by('cat_id', 'desc');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	function total_count_file_category() {
		$pr = $this->db->dbprefix('file_category');
		$query = $this->db->query("SELECT COUNT(cat_id) AS tot FROM ".$pr." ");
		$s = $query->result();
		return $s[0]->tot;
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$pr = $this->db->dbprefix('download_files');
		$query = $this->db->query("SELECT COUNT(id) AS tot FROM ".$pr." ");
		$s = $query->result();
		return $s[0]->tot;
	}

	// function to insert page in database
	function add_download() {
		$this->file_user_type = $this->input ->post("file_user_type", TRUE);
		$this->language_ = $this->input ->post("language", TRUE);
		$this->file_details = $this->input ->post("file_details", TRUE);
		$this->file_name = $this->input ->post("file_name", TRUE);
		$this->file_id = $this->input ->post("cat_id", TRUE);
		$this->add_date = date("Y-n-j H:i:s"); 
		$ok = $this->db ->insert('download_files', $this);

		$session_data = $this->session->userdata('file_pic');
		$cacheid = $session_data['fileid_'];

		if ($ok) {
			$lastid = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;

			//update yapacagımız files için çünkü cache_id ye göre gittiğimiz için diğer değerler boşta kalıyor

			$data = array("rec_id" => $lastid);
			$this->db ->where('cache_id', $cacheid);
			$ok = $this->db ->update('files', $data);
			//session ı yok et
			$this->session->unset_userdata('file_pic');

		}
		return $lastid;
	}

	// function to insert page in database
	function add_download_cat() {
		$this->category_explanation = $this->input ->post("category_explanation", TRUE);
		$this->category_explanation_en = $this->input ->post("category_explanation_en", TRUE);
		$this->top_category_id = $this->input ->post("cat_id", TRUE);

		$ok = $this->db ->insert('file_category', $this);
		if ($ok) {
			$lastid = $this->db ->insert_id();

		}
		return $lastid;
	}

	//toplam dosya sayısı
	function total_count_file($cache_id) {
		$pr = $this->db->dbprefix('files');
		$query = $this->db->query("SELECT COUNT(*) AS t FROM ".$pr." where cache_id=".$cache_id." ");
		$returned = $query->result();
		return $returned[0]->t;
	}

	//dosya ekleme files db ye
	function add_file($cache_id, $pic_count, $id = NULL) {

		$this->file_name = $this->input ->get("name", TRUE);
		$this->size = $this->input ->get("size", TRUE);
		$this->file_type = $this->input ->get("ext", TRUE);
		$this->mod_type = 'indirilebilir_dosya';
		$this->cache_id = $cache_id;
		$this->rec_id = $id != NULL ? $id : '0';
		$ok = $this->db ->insert('files', $this);
		$lastid = $this->db ->insert_id();
		$t = $this->total_count_file($cache_id);
		//$t = $t - 1;
		if ($t > $pic_count) {
			@unlink(FCPATH.'/uploads/files/'.$this->pictures);
			$this->db ->where('id', $lastid);
			$this->db ->delete('files');
			if ($this->total_count_file($cache_id) != 2) {
				return 'error';
			}
		} else {
			return $lastid;
		}

	}

	function get_files_cat($id) {
		$this->db ->select('*');
		$this->db ->where('cat_id', $id, '=');
		$this->db ->from('file_category');
		$query = $this->db ->get();
		return ($query->result());
	}

	//dosya güncelleme
	function update_files_cat() {
		$id = $this->uri ->segment(4);

		$data = array(
			"category_explanation" => $this->input ->post("category_explanation", TRUE),
			"top_category_id" => $this->input ->post("cat_id", TRUE),
			"category_explanation_en" => $this->input ->post("category_explanation", TRUE));

		$this->db ->where('cat_id', $id);
		$this->db ->update('file_category', $data);

	}

	function cat_delete($id) {
		$count = $this->db ->get('file_category');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$this->db ->where('cat_id', $id);
			$ok = $this->db ->delete('file_category');
			if ($ok) {
				return 2;
			} else {
				return 3;

			}

		}

	}

	//dosya güncelleme
	function update_files() {
		$id = $this->uri ->segment(4);
		// get fileds from post
		$data = array(
			"title" => $this->input ->post("title", TRUE),
			"spot" => $this->input ->post("spot", TRUE),
			"type" => $this->input ->post("type", TRUE),
			"source" => $this->input ->post("source", TRUE),
			"picture" => $this->input ->post("picture_", TRUE),
			"flash" => $this->input ->post("flash", TRUE),
			"duration_date" => $this->input ->post("duration_date", TRUE),
			"language" => $this->input ->post("language", TRUE),
			"details" => $this->input ->post("details", TRUE));
		$this->db ->where('id', $id);
		$this->db ->update('news', $data);

	}

	//
	function get_download_files($id) {
		$this->db ->select('*');
		$this->db ->where('id', $id, '=');
		$this->db ->from('download_files');
		$query = $this->db ->get();
		return ($query->result());
	}

	function get_files($id) {
		$this->db ->select('*');
		$this->db ->where('rec_id', $id, '=');
		$this->db ->from('files');
		$query = $this->db ->get();
		return ($query->result());
	}

	/// bunun daha kısa kodu lazım tek deger veren bir sql sadece value verse yetecek araştır e<sql de vardı boyle bişi
	function get_file($id) {
		/* $pr = $this->db->dbprefix('files');
		 $query = $this->db->query("SELECT file_name FROM ".$pr." WHERE id ='".$id."' limit 1 ");
		 $pic = $query->result();
		 return 	$pic = $pic[0]->pictures;*/
		$this->db ->select('file_name');
		$this->db ->where('id', $id, '=');
		$this->db ->from('files');
		$query = $this->db ->get();
		$query = $query->result();
		return $query[0]->file_name;

	}

	function delete() {
		$count = $this->db ->get('news');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('download_files', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

	function file_delete($id) {
		$count = $this->db ->get('files');
		if ($count->num_rows() == 1) {
			return 1;
		} else {

			$this->db ->where('id', $id);
			$ok = $this->db ->delete('files');
			if ($ok) {
				return 2;
			} else {
				return 3;

			}

		}

	}

}
?>
