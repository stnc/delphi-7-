<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Contact_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_contact($perpage, $segment) {
		$this->db ->select('contact.*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('contact');
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}


	function total_count() {
		$pr = $this->db->dbprefix('contact');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database
	function add_contact() {
		$this->title = $this->input ->post("title", TRUE);
		$this->spot = $this->input ->post("spot", TRUE);
		$this->source = $this->input ->post("source", TRUE);
		$this->type = $this->input ->post("type", TRUE);
		$this->flash = $this->input ->post("flash", TRUE);
		$this->picture = $this->input ->post("picture_", TRUE);
		$this->duration_date = tr_date_add($this->input ->post("duration_date", TRUE));
		$this->language = $this->input ->post("language", TRUE);
		$this->details = $this->input ->post("details", TRUE);
		$ok = $this->db ->insert('contact', $this);

		if ($ok) {
			$this->res = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;
			}
		return $this->res;
	}


	function update_contact() {

		$id = $this->uri ->segment(4);

		// get fileds from post
		$data = array(
			"title" => $this->input ->post("title", TRUE),
			"spot" => $this->input ->post("spot", TRUE),
			"type" => $this->input ->post("type", TRUE),
			"source" => $this->input ->post("source", TRUE),
			"picture" => $this->input ->post("picture_", TRUE),
			"flash" => $this->input ->post("flash", TRUE),
			"duration_date" => $this->input ->post("duration_date", TRUE),
			"language" => $this->input ->post("language", TRUE),
			"details" => $this->input ->post("details", TRUE));
		$this->db ->where('id', $id);
		$this->db ->update('contact', $data);

	}

	function get_contact($contact_id) {
		/*$contact_id = $this->db->escape($this->uri->segment(4));
		 $this->db->select('contact.*,  section.id as  sid ');*/
		$this->db ->select('contact.*');
		$this->db ->where('contact.id', $contact_id, '=');
		$this->db ->from('contact');
		$query = $this->db ->get();
		return ($query->result());
	}




	function delete() {
		$count = $this->db ->get('contact');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('contact', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}



}
?>
