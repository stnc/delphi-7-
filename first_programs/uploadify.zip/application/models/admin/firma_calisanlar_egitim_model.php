<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_calisanlar_egitim_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	
	function get_firmalar($firmalar_id = NULL) {
		$this->db ->select(' firma_id as id,muhendis,maviyaka,beyazyaka,toplam,ortalama_egitim');
		$this->db ->from('firma_calisan_egitimleri as calisan');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
	    return $query->result();
	
	}


	function firma_ismi($id=NULL) {
	
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	
	

	function update() {
		$id = $this->uri ->segment(4);
		$data = array(
			"maviyaka"  =>  $this->input ->post("maviyaka", TRUE),
			"beyazyaka" =>  $this->input ->post("beyazyaka",TRUE),
			"ortalama_egitim"=>$this->input ->post("ortalama_egitim",TRUE),
			"muhendis"  =>  $this->input ->post("muhendis", TRUE)
		);
		$this->db ->where('firma_id', $id);
		$this->db ->update('firma_calisan_egitimleri', $data);

	}


}
?>
