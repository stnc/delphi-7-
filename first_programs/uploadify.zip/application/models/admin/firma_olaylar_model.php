<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class firma_olaylar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	
	
	//firnmaların listesi 
	function list_firmalar($perpage, $segment) {
		$this->db ->select('firma_adi,firma_eposta,id');
		//$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	//firnmaların listesi
	function list_firmalar_tumu() {
		$this->db ->select('firma_adi,id');
		//$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	



	//firmalar toplamı
	function total_count() {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." ");//where record_status <>0
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}
	
	

	//firmanın adını verir 
	function firma_ismi($id=NULL) {
		
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	
	
	
		//firmanın id si çok gerekli değildi saece doğrulama amaçlı olsun diye 
	function firma_id($id=NULL) {
	
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}
	
	function ilk_siradaki_id() {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."   order by id desc  ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}
	
	
	
	
	
	
	


}
?>
