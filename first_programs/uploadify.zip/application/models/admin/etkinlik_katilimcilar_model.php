<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Etkinlik_katilimcilar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_news($perpage, $segment) {
		//$query = $this -> db -> get('news'); tumunu verir
		//$query = $this->db ->query('select * from '. $this->db->dbprefix('news').' where record_status<>0 order by id desc');

		$this->db ->select(' et.*,pa.activity_title,pc.start_date,pc.end_date');
	//	$this->db ->where('record_status <>', '0');
		$this->db ->from('etkinlik_talep as et');
		$this->db->join('activity as pa', 'et.fk_takvim_id=pa.id');
		$this->db->join('activity_calendar  as pc', 'pc.activity_id=pa.id');
		$this->db->order_by('talep_id', 'desc');
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$this->db ->select('COUNT(*) AS toplam');
		$this->db ->from('etkinlik_talep as et');
		$this->db->join('activity as pa', 'et.fk_takvim_id=pa.id');
		$this->db->join('activity_calendar  as pc', 'pc.activity_id=pa.id');
		$query = $this->db ->get();
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	





}
?>
