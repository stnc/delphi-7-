<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class News_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_news($perpage, $segment) {
		//$query = $this -> db -> get('news'); tumunu verir
		//$query = $this->db ->query('select * from '. $this->db->dbprefix('news').' where record_status<>0 order by id desc');

		$this->db ->select('news.*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('news');
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$pr = $this->db->dbprefix('news');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database
	function add_news() {
		$this->title = $this->input ->post("title", TRUE);
		$this->spot = $this->input ->post("spot", TRUE);
		$this->source = $this->input ->post("source", TRUE);
		$this->type = $this->input ->post("type", TRUE);
		$this->flash = $this->input ->post("flash", TRUE);
		$this->picture = $this->input ->post("picture_", TRUE);
		$this->duration_date = tr_date_add($this->input ->post("duration_date", TRUE));
		$this->language = $this->input ->post("language", TRUE);
		$this->details = $this->input ->post("details", TRUE);
		$ok = $this->db ->insert('news', $this);

		if ($ok) {
			$this->res = $this->db ->insert_id();
			//$data['lastid'] = $this->db->insert_id() ;
			}
		return $this->res;
	}

	function total_count_file($cache_id) {
		$pr = $this->db->dbprefix('news_pictures');
		$query = $this->db->query("SELECT COUNT(id) AS t FROM ".$pr." where cache_id=".$cache_id." ");
		$returned = $query->result();
		return $returned[0]->t;
	}

	function add_file($cache_id,$pic_count) {

		$this->pictures = $this->input ->get("name", TRUE);
		$this->cache_id = $cache_id;
		$ok = $this->db ->insert('news_pictures', $this);
		$lastid = $this->db ->insert_id();
		$t = $this->total_count_file($cache_id);
		//$t = $t - 1;
		if ($t > $pic_count) {
			@unlink(FCPATH.'/uploads/haberler/'.$this->pictures);
			$this->db ->where('id', $lastid);
			$this->db ->delete('news_pictures');
			if ($this->total_count_file($cache_id) != 2) {
				return 'error';
			}
		} else {
			return $lastid;
		}

	}

	function update_news() {

		$id = $this->uri ->segment(4);

		// get fileds from post
		$data = array(
			"title" => $this->input ->post("title", TRUE),
			"spot" => $this->input ->post("spot", TRUE),
			"type" => $this->input ->post("type", TRUE),
			"source" => $this->input ->post("source", TRUE),
			"picture" => $this->input ->post("picture_", TRUE),
			"flash" => $this->input ->post("flash", TRUE),
			"duration_date" => $this->input ->post("duration_date", TRUE),
			"language" => $this->input ->post("language", TRUE),
			"details" => $this->input ->post("details", TRUE));
		$this->db ->where('id', $id);
		$this->db ->update('news', $data);

	}

	function get_news($news_id) {
		/*$news_id = $this->db->escape($this->uri->segment(4));
		 $this->db->select('news.*,  section.id as  sid ');*/
		$this->db ->select('news.*');
		$this->db ->where('news.id', $news_id, '=');
		$this->db ->from('news');
		$query = $this->db ->get();
		return ($query->result());
	}


	function get_file($id) {
		//daha kısası download_model de get_file fonksiyonu içinde comment yerindedir
		$this->db ->select('pictures');
		$this->db ->where('id', $id, '=');
		$this->db ->from('news_pictures');
		$query = $this->db ->get();
		$query = $query->result();
		return  $query [0]->pictures;
	}

	function delete() {
		$count = $this->db ->get('news');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('news', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

	function file_delete($id) {
		$count = $this->db ->get('news_pictures');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$data = array("picture" => '');
			$this->db ->where('id', $id);
			$ok = $this->db ->delete('news_pictures');
			if ($ok) {
				return 2;
			} else {
				return 3;

			}

		}

	}

}
?>
