<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_arge_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function gets($firmalar_id = NULL) {
		$this->db ->select('*');
		$this->db ->from('firma_arge');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
		return $query->result();

	}

	function firma_ismi($id = NULL) {

		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function update() {
		$id = $this->uri ->segment(4);
		$data = array(
			"arge_muhendis_sayisi" => $this->input ->post("arge_muhendis_sayisi", TRUE),
			"firma_arge_sirketi" => $this->input ->post("firma_arge_sirketi", TRUE),
				"arge_merkezi" => $this->input ->post("arge_merkezi", TRUE),
				"arge_departmani" => $this->input ->post("arge_departmani", TRUE),
				"alinan_patent_sayisi" => $this->input ->post("alinan_patent_sayisi", TRUE),
				"alinan_faydali_model_sayisi" => $this->input ->post("alinan_faydali_model_sayisi", TRUE),
				"dizayn_asama_uretilen" => $this->input ->post("dizayn_asama_uretilen", TRUE),
				"yillik_toplam_yeni_urun_adet" => $this->input ->post("yillik_toplam_yeni_urun_adet", TRUE),
				"patent_basvuru_sayisi" => $this->input ->post("patent_basvuru_sayisi", TRUE),
				"hibe_programina_basvuru_sayisi" => $this->input ->post("hibe_programina_basvuru_sayisi", TRUE)
		);
		$this->db ->where('firma_id', $id);
		$this->db ->update('firma_arge', $data);

	}

}
?>
