<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class General_model extends CI_Model {

	private $table_semt = "semt";
	private $table_town = "ilce";
	//private $table_section = "section";

	function __construct() {

		parent::__construct();
		$this->load ->database();
	}



	//şehirleri listele
	function list_city() {
		$query = $this->db ->get('il');
		//	$this->db->order_by('town','ASC');
		return $query->result();
	}
	
	
	//ükleri listeler
	function list_ulke() {
		$query = $this->db ->get('kat_ulkeler');
		//	$this->db->order_by('town','ASC');
		return $query->result();
	}
	
	
	//dosya kategtorileri
	function list_files() {
		$this->db ->select('category_explanation,cat_id');
		$this->db->order_by('order','desc');
		$query = $this->db ->get('file_category');
		return $query->result();
	}
	
	

	//seçilen ile göre ona bağlı ilçeler 
	function get_town_list($type) {
		$this->db ->select('ILCE_ADI,ILCE_ID');
		$this->db ->where('IL_ID', $type, '=');
		$this->db ->order_by('ILCE_ADI', 'ASC');
		$query = $this->db ->get($this->table_town);
		return $query->result();
	}
	
//seçilen ilçe id ye göre ona bağlı semt ler gelir 
	function get_district_list($type) {
		$this->db ->select('SEMT_ADI,SEMT_ID');
		$this->db ->where('ILCE_ID', $type, '=');
		$this->db ->order_by('SEMT_ADI', 'ASC');
		$query = $this->db ->get($this->table_semt);
		return $query->result();
	}

	
	
	
//id ye göre kurumlar 
	function get_kurumlar_list_param($type) {
		$this->db ->select('kurum_adi,id');
		$this->db ->where('id', $type, '=');
		$this->db ->order_by('kurum_adi', 'ASC');
		$query = $this->db ->get($this->table_semt);
		return $query->result();
	}

	///tüm kurumlar 
	function list_kurumlar() {
	$this->db ->select('kurum_adi,id');
		$this->db ->order_by('id', 'ASC');
		$query = $this->db ->get('etkinlik_egitim_kurumlari');
		return $query->result();
		//var_dump( $query->result());
		

	}

}
?>