<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_iletisim_adresleri_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_firma_iletisim_adresleri($perpage, $segment, $search = NULL) {
		$this->db ->select('*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		if ($search != NULL) {
			$this->db->like('firma_adi', $search);
		}
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();

		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	function total_count_search($search) {
		$pr = $this->db->dbprefix('firmalar');
		$s = $search != NULL ? " AND `firma_adi` LIKE '%".$search."%'" : '';
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0 $s");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$pr = $this->db->dbprefix('firma_iletisim_adresleri');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database  ekleme
	function add_firmalar() {

		$data = array(

			"il_id" => $this->input ->post("center_city", TRUE),
			"ulke_id" => $this->input ->post("ulkeler", TRUE),
			"ilce_id" => $this->input ->post("center_town", TRUE),
			"semt_id" => $this->input ->post("center_district", TRUE),
			"firma_telefon" => $this->input ->post("firma_telefon", TRUE),
			"firma_faks" => $this->input ->post("firma_faks", TRUE),

			"vergi_dairesi" => $this->input ->post("vergi_dairesi", TRUE),
			"firma_adres" => $this->input ->post("firma_adres", TRUE),
			"posta_kodu" => $this->input ->post("posta_kodu", TRUE),
			"vergi_numarasi" => $this->input ->post("vergi_numarasi", TRUE),
			"iletisim_adres_turu" => $this->input ->post("iletisim_adres_turu", TRUE),

			"eklenme_tarihi" => date("Y-n-j H:i:s")
		);

		$ok = $this->db ->insert('firma_iletisim_adresleri', $data);

		//echo $this->db ->last_query();

		if ($ok) {
			$res = $this->db ->insert_id();
			return $res;
		}

	}

	function update_firmalar() {

		$id = $this->uri ->segment(4);

		$data = array(

			"firma_ticari_unvan" => $this->input ->post("firma_ticari_unvan", TRUE),
			"il_id" => $this->input ->post("center_city", TRUE),
			"ulke_id" => $this->input ->post("ulke", TRUE),
			"ilce_id" => $this->input ->post("center_town", TRUE),
			"semt_id" => $this->input ->post("center_district", TRUE),
			"firma_telefon" => $this->input ->post("firma_telefon", TRUE),
			"firma_faks" => $this->input ->post("firma_faks", TRUE),
			"vergi_dairesi" => $this->input ->post("vergi_dairesi", TRUE),
			"firma_adres" => $this->input ->post("firma_adres", TRUE),
			"vergi_numarasi" => $this->input ->post("vergi_numarasi", TRUE),
			"iletisim_adres_turu" => $this->input ->post("iletisim_adres_turu", TRUE),
			"posta_kodu" => $this->input ->post("posta_kodu", TRUE)
		);
		$this->db ->where('id', $id);
		$this->db ->update('firma_iletisim_adresleri', $data);

	}

	function get_firmalar($firmalar_id) {
		/*$firmalar_id = $this->db->escape($this->uri->segment(4));
		 $this->db->select('firmalar.*,  section.id as  sid ');*/
		$this->db ->select('*');
		$this->db ->where('firmalar.id', $firmalar_id, '=');
		$this->db ->from('firma_iletisim_adresleri');
		$query = $this->db ->get();
		return ($query->result());
	}

	function delete() {
		$count = $this->db ->get('firma_iletisim_adresleri');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('firma_iletisim_adresleri', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

}
?>
