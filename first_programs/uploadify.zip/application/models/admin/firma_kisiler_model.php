<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_kisiler_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_firmalar($perpage, $segment, $search = NULL) {
		$this->db ->select('firmalar.*');
		$this->db ->where('record_status <>', '0');
		$this->db ->from('firmalar');
		if ($search != NULL) {
			$this->db->like('firma_adi', $search);
		}
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	
	
	function total_count_search($search = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$s = $search != NULL ? " AND `firma_adi` LIKE '%".$search."%'" : '';
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0 $s");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	//bu aslında generale konmalı parametre ile her değere göre vermeli *----fiix
	function total_count() {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where record_status <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database  ekleme
	function add() {

		$data = array(
			"firma_id" => $firma_id,
				"departman_id" => $this->input ->post("departman", TRUE),
			"unvan" => $this->input ->post("unvan", TRUE),
			"adsoyad" => $this->input ->post("adsoyad", TRUE),
			"telefon" => $this->input ->post("telefon", TRUE),
			"kullanici_adi" => '00000',
			"sifre" => '00000',
			"eklenme_tarihi" => date("Y-n-j H:i:s")
		);

		$ok = $this->db ->insert('firma_kisiler', $data);

		//echo $this->db ->last_query();

		if ($ok) {
			$res = $this->db ->insert_id();
			return $res;
		}
	}

	
	function update() {
		$id = $this->uri ->segment(4);
		$data = array(
			"firma_id" => $this->input ->post("firma_id", TRUE),
			"departman_id" => $this->input ->post("departman", TRUE),
			"telefon" => $this->input ->post("telefon", TRUE),
			"unvan" => $this->input ->post("unvan", TRUE),
			"adsoyad" => $this->input ->post("adsoyad", TRUE),
			"telefon" => $this->input ->post("telefon", TRUE),
			"eposta" => $this->input ->post("eposta", TRUE),
			"adsoyad" => $this->input ->post("adsoyad", TRUE)
		);
		$this->db ->where('id', $id);
		$this->db ->update('firma_kisiler', $data);

	}

	function get_firmalar($firmalar_id) {
		$this->db ->select('*');
		$this->db ->where('id', $firmalar_id, '=');
		$this->db ->from('firma_kisiler');
		$query = $this->db ->get();
		return ($query->result());
	}
	
	
	function get_firma_iletisim_departmanlar() {
		$this->db ->select('*');
		$this->db ->from('firma_iletisim_departmanlar');
		$query = $this->db ->get();
		return ($query->result());
	}

	function delete() {
		$count = $this->db ->get('firmalar');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('firmalar', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

}
?>
