<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_urun_kodlari_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function firma_ismi($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}

	function liste() {
		$this->db ->select('*');
		$this->db ->from('kat_urun_kodlari');
		$query = $this->db ->get();
		return $query->result();
	}

	function secili_liste($id) {
		$this->db ->select('urun_id as id');
		$this->db ->from('firma_urun_kodlari');
		$this->db ->where('firma_id', $id, '=');
		$query = $this->db ->get();
		//object yapıdan çıkardım inarray olması için kontrolu için yeni bi arrayde grupladım
		foreach ($query->result() as $db_) {
			$db_den2[] = $db_->id;
		}
		if (empty($db_den2))
			$db_den2 = NULL; //eğer hiç bişey yoksa null göndersin hata basmasın ekrana
		return $db_den2;
	}

	function update($id = NULL) {
		$this->db ->where('firma_id', $id);
		$this->db ->delete('firma_urun_kodlari');

		$posttan = $this->input->post("belge");
		foreach ($posttan as $p) {
			$data = array(
				"firma_id" => $id,
				"urun_id" => $p
			);

			$this->db ->insert('firma_urun_kodlari', $data);
		}

	}

}
?>
