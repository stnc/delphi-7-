<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Administrator_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function list_admin($perpage, $segment) {
		$this->db ->select('*');
		$this->db ->where('status_ <>', '0');
		$this->db ->from('admins');
		$this->db ->order_by('id','asc');
		$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}


	function total_count() {
		$pr = $this->db->dbprefix('admins');
		$query = $this->db->query("SELECT COUNT(id) AS toplam FROM ".$pr." where status_ <>0");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	// function to insert page in database
	function add_admin() {
		$this->email_address = $this->input ->post("email_address", TRUE);
		$this->username = $this->input ->post("username", TRUE);
		$this->password = SHA1($this->input ->post("password2", TRUE));
		$this->add_date= date("Y-n-j H:i:s");
		$ok = $this->db ->insert('admins', $this);
		if ($ok) {
			$this->res = $this->db ->insert_id();
		}
		return $this->res;
	}

	function update_admin() {

		$id = $this->uri ->segment(4);

		$data = array(
			//"email_address" => $this->input ->post("email_address", TRUE),
			"update_date"=> date("Y-n-j H:i:s"),
			//"username" => $this->input ->post("username", TRUE),
			"password" => SHA1($this->input ->post("password2", TRUE))
		);
		$this->db ->where('id', $id);
		$this->db ->update('admins', $data);

	}

	function get_admin($news_id) {
		$this->db ->select('*');
		$this->db ->where('id', $news_id, '=');
		$this->db ->from('admins');
		$query = $this->db ->get();
		return ($query->result());
	}

	function delete() {
		$count = $this->db ->get('admins');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("status_" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('admins', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

}
?>
