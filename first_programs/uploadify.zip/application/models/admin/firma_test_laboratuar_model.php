<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_test_laboratuar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	
	
	function gets($firmalar_id = NULL) {
		$this->db ->select('*');
		$this->db ->from('firma_test_laboratuar');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
	    return $query->result();
	
	}


	function firma_ismi($id=NULL) {
	
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	
	

	function update() {
		$id = $this->uri ->segment(4);
		$data = array(
			"yapilabilen_testler" => $this->input ->post("yapilabilen_testler", TRUE),
				"labaratuari_onaylayan_firmalar" => $this->input ->post("labaratuari_onaylayan_firmalar", TRUE),
				"test_laboratuari" => $this->input ->post("test_laboratuari", TRUE),
				
				"ts_en_akreditasyon" => $this->input ->post("ts_en_akreditasyon", TRUE),
				"urunlerin_tamami_test_imkani" => $this->input ->post("urunlerin_tamami_test_imkani", TRUE),
				"labratuar_disariya_hizmet" => $this->input ->post("labratuar_disariya_hizmet", TRUE),
				"lab_anasayi_firma_onay" => $this->input ->post("lab_anasayi_firma_onay", TRUE),
				"labaratuarin_turu" => $this->input ->post("labaratuarin_turu", TRUE)
				
		);
		$this->db ->where('firma_id', $id);
		$this->db ->update('firma_test_laboratuar', $data);

	}


}
?>
