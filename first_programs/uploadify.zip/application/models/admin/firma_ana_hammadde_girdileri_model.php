<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_ana_hammadde_girdileri_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}

	function liste($firmalar_id = NULL) {
		$this->db ->select('*');
		$this->db ->from('firma_ana_hammadde_girdileri');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
		return $query->result();

	}
	
	function get_edit($firmalar_id) {
		$this->db ->select('*');
		$this->db ->where('id', $firmalar_id, '=');
		$this->db ->from('firma_ana_hammadde_girdileri');
		$query = $this->db ->get();
		return $query->result();
	}

	function total_count($id) {
		$pr = $this->db->dbprefix('firma_ana_hammadde_girdileri');
		$query = $this->db->query("SELECT COUNT(*) AS toplam FROM ".$pr."  where firma_id=".$id."  ");
		$sonuc = $query->result();
		return $sonuc[0]->toplam;
	}

	function firma_ismi($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}

	function delete() {
		$count = $this->db ->get('firma_ana_hammadde_girdileri');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			//$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->delete('firma_ana_hammadde_girdileri', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}

	function update() {
	
		$id = $this->uri ->segment(4);
		$data = array(
			"firma_id" => $this->input ->post("firma_id", TRUE),
			"ulke_id" => $this->input ->post("ulkeler", TRUE),
			"miktar" => $this->input ->post("miktar", TRUE),
			"hammadde" => $this->input ->post("hammadde", TRUE),
			"birim" => $this->input ->post("birim", TRUE)

		);
		$this->db ->where('id', $id);
		$this->db ->update('firma_ana_hammadde_girdileri', $data);
	
	}
	
	
	function add() {
		$id = $this->uri ->segment(4);
		$data = array(
			"firma_id" => $id,
	
			"ulke_id" => $this->input ->post("ulkeler", TRUE),
			"miktar" => $this->input ->post("miktar", TRUE),
			"hammadde" => $this->input ->post("hammadde", TRUE),
			"birim" => $this->input ->post("birim", TRUE)
	
		);
		$this->db ->insert('firma_ana_hammadde_girdileri', $data);
	}

}
?>
