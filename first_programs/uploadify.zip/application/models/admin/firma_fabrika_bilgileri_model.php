<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_fabrika_bilgileri_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}
/*
	

	function delete() {
		$count = $this->db ->get('firmalar');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->update('firmalar', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}
	
	

	*/
	
	function get_firmalar($firmalar_id = NULL) {
		$this->db ->select('*');
		$this->db ->from('firma_fabrika_bilgileri');
		$this->db ->where('firma_id', $firmalar_id, '=');
		$query = $this->db ->get();
	    return $query->result();
	
	}


	function firma_ismi($id=NULL) {
	
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}
	
	

	function update_firmalar() {
		$id = $this->uri ->segment(4);
		$data = array(
		"fabrika_adi_yeri1" => $this->input ->post("fabrika_adi_yeri1", TRUE),
	    "fabrika_adi_yeri2" => $this->input ->post("fabrika_adi_yeri2", TRUE),
		"fabrika_adi_yeri3" => $this->input ->post("fabrika_adi_yeri3", TRUE),
		"toplam_alan1" => $this->input ->post("toplam_alan1", TRUE),
		"toplam_alan2" => $this->input ->post("toplam_alan2", TRUE),
		"toplam_alan3" => $this->input ->post("toplam_alan3", TRUE),
		"kapali_alan1" => $this->input ->post("kapali_alan1", TRUE),
		"kapali_alan2" => $this->input ->post("kapali_alan2", TRUE),
	  	"kapali_alan3" => $this->input ->post("kapali_alan3", TRUE),	
		"vardiya_sayisi" => $this->input ->post("vardiya_sayisi", TRUE),
        "kapasite_kullanim_orani" => $this->input ->post("kapasite_kullanim_orani", TRUE)
				
		);
				
		
		$this->db ->where('firma_id', $id);
		$this->db ->update('firma_fabrika_bilgileri', $data);

	}


}
?>
