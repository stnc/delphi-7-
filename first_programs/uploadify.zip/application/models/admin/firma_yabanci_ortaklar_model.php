<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Firma_yabanci_ortaklar_model extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}


	function firma_ismi($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}

	function firma_id($id = NULL) {
		$pr = $this->db->dbprefix('firmalar');
		$query = $this->db->query("SELECT id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}

	
/*	function firma_ismi_($id = NULL) {
		$pr = $this->db->dbprefix('firma_yabanciortaklar');
		$query = $this->db->query("SELECT firma_adi FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->firma_adi;
	}
	
	function firma_id_($id = NULL) {
		$pr = $this->db->dbprefix('firma_yabanciortaklar');
		$query = $this->db->query("SELECT firma_id FROM ".$pr."  where id=".$id." ");
		$sonuc = $query->result();
		return $sonuc[0]->id;
	}
	*/
	
	
	function firmanin_yabanci_ortakliklari($id) {
		$this->db ->select('*');
		$this->db ->from('firma_yabanciortaklar');
		$this->db ->where('firma_id', $id, '=');
		//$this->db->limit($perpage, $segment);
		$query = $this->db ->get();
	//	echo $this->db->last_query();
		return $query->result();
	}
	
	
	function ortak($id) {
		$this->db ->select('*');
		$this->db ->from('firma_yabanciortaklar');
		$this->db ->where('id', $id, '=');
		$query = $this->db ->get();
		return $query->result();
	}
	
	
	function total_count($id) {
		$pr = $this->db->dbprefix('firma_yabanciortaklar');
		$query = $this->db->query("SELECT COUNT(*) AS toplam FROM ".$pr."  where firma_id=".$id."  ");
		$sonuc = $query->result();
	//	echo $this->db->last_query();
		return $sonuc[0]->toplam;
	}
	
	
	function ortak_duzenle() {
		$id = $this->uri ->segment(4);
		// get fileds from post
		$data = array(
		//"firma_id" => $id,
		"ulkesi" => $this->input ->post("ortakulke", TRUE),
		"ortak_adi" => $this->input ->post("ortakad", TRUE),		
	    "yuzde" => $this->input ->post("oyuzde", TRUE),
		"ortalik_turu" => $this->input ->post("ortalik_turu", TRUE),	
	    "yabanci_ortak" => $this->input ->post("yabanciortak", TRUE)
		);
		$this->db ->where('id', $id);
		$this->db ->update('firma_yabanciortaklar', $data);

	}

	function delete() {
		$count = $this->db ->get('firma_yabanciortaklar');
		if ($count->num_rows() == 1) {
			return 1;
		} else {
			$id = $this->uri ->segment(4);
			//$data = array("record_status" => 0);
			$this->db ->where('id', $id);
			$ok = $this->db ->delete('firma_yabanciortaklar', $data);
			if ($ok) {
				return 2;
			} else {
				return 3;
			}
		}
	}
	
	function ortak_ekle() {
		$id = $this->uri ->segment(4);
		// get fileds from post
		$data = array(
		"firma_id" => $id,
		"ulkesi" => $this->input ->post("ortakulke", TRUE),
		"ortak_adi" => $this->input ->post("ortakad", TRUE),		
	    "yuzde" => $this->input ->post("oyuzde", TRUE),
		"ortalik_turu" => $this->input ->post("ortalik_turu", TRUE),
	    "yabanci_ortak" => $this->input ->post("yabanciortak", TRUE)
		);
		
		$ok = $this->db ->insert('firma_yabanciortaklar', $data);

		if ($ok) {
			$this->res = $this->db ->insert_id();
		}
		return $this->res;
	}
	

}
?>
