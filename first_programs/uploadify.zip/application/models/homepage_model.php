<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Homepage_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';

	private $table_news = "news";

	private $res = '';

	function __construct() {

		parent::__construct();
		$this->load ->helper('datetime');
	}


	

}
?>
