<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Pages_model extends CI_Model {

	//var $name ='';

	//var $visible ='Yes';
//http://users.ugent.be/~kblom/user_guide/tutorial/create_news_items.html

	function __construct() {

		parent::__construct();

	}

	
	
	//profil_yabanci_ortak_varmi aktairldi
	
	function firma_sayi() {
		$pr = $this->db->dbprefix('firmalar');
		$query=$this->db->query("SELECT COUNT(id) as total FROM ".$pr." WHERE kayit_durum=2;  ");
		$returned=$query->result();
		return $returned[0]->total;
	}
	
	function firma_sayi2() {
		$pr = $this->db->dbprefix('firmalar');
		$query=$this->db->query("SELECT COUNT(id)  as total FROM ".$pr." WHERE kayit_durum=2 AND profil_yabanci_ortak_varmi = 1; ");
		$returned=$query->result();
		return $returned[0]->total;
	
	}
	
	//burayı henuz kullana yok ortak kullanıma koymam lazım bunu 
	function list_pages($limit = NULL,$costum=NULL) {
		$pr = $this->db->dbprefix('pages');
		$limit = $limit == NULL ? '' : 'limit '.$limit;
		$costum =$costum == NULL ? '' : $costum;
		$s='select * from '.$pr.' where record_status<>0 '.$costum.'  order by id desc '.$limit.'';
		$query = $this->db ->query($s);
		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	
	//sayfa gelsin
	function get_page($news_id=NULL) {
		// $news_id = $this->db->escape($this->uri->segment(3));
		//$news_id = (int) $this->input ->post('id');
		
		//$news_id = $news_id!=NULL ? $news_id : $this->uri ->segment(2);//kullandım
		
		$this->load->helper('url');
		
		$slug = url_title( $this->uri ->segment(2), TRUE);
		
		
		$query = $this->db->get_where('pages', array('slug' => $slug));
	
		if ($query->num_rows() > 0) {
			$this->db ->select('pages.*');
			$this->db ->where('pages.slug', $slug, '=');
			//$this->db ->where('pages.id', $news_id, '=');
			$this->db ->from('pages');
			//$this->db->join('section', 'section.id = news.section_id');
			//$this->db->join('town', 'town.id = news.i_town');
			$query = $this->db ->get();
			return ($query->result());
		} else {
			return false;
		}
		
		
	

	
	}

}
?>
