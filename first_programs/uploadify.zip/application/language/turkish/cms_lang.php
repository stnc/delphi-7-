<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');


$lang['personal_page_section_id'] = 'Bölüm';
$lang['personal_page_p_position_id'] = 'Pozisyon';
$lang['personal_page_personal_no'] = 'Personel Numarası';
$lang['personal_page_personalAdd'] = 'Personel Ekleme';
$lang['personal_page_name'] = 'Ad';
$lang['personal_page_surname'] = 'Soyad';
$lang['personal_page_personal_indintity_knowledge'] = 'Personel Kimlik Bilgileri';
$lang['personal_page_i_series'] = 'Kimlik Seri Numarası';
$lang['personal_page_i_inumber'] = 'Kimlik Numarası';
$lang['personal_page_tax_number'] = 'TC Kimlik Numarası';
$lang['personal_page_i_FatherName'] = 'Baba Adı';
$lang['personal_page_i_MotherName'] = 'Anne Adı';
$lang['personal_page_i_BornPlace'] = 'Doğum Yeri';
$lang['personal_page_i_BornDate'] = 'Doğum Tarihi';
$lang['personal_page_i_LawCivil'] = 'Medeni Hal';
$lang['personal_page_i_city'] = 'Şehir';
$lang['personal_page_i_town'] = 'İlçe';
$lang['personal_page_i_neighborhood'] = 'Mahalle/Köy';
$lang['personal_page_firm_risk'] = 'Cild Numarası';
$lang['personal_page_i_FamilyNumber'] = 'Aile Sıra Numarası';
$lang['personal_page_i_order_no'] = 'Sıra Numarası';
$lang['personal_page_tax_verge'] = 'Kayıt No';
$lang['personal_page_i_IdentifyLocation'] = 'Verildiği Yer';
$lang['personal_page_i_whyGive'] = 'Veriliş Nedeni';
$lang['personal_page_i_GiveDate'] = 'Veriliş Tarihi';
$lang['personal_page_adress_1'] = 'Adres 1';
$lang['personal_page_adress_2'] = 'Adres 2';
$lang['personal_page_gsm_number'] = 'Cep Telefonu';
$lang['personal_page_home_number'] = 'Ev Telefonu';
$lang['personal_page_gsm_number2'] = 'Cep Telefonu';
$lang['personal_page_alternative_number'] = 'Alternatif Telefon';
$lang['personal_page_email_adress'] = 'E-mail Adresi';
$lang['personal_page_p_register_number'] = 'Sicil Numarası';
$lang['personal_page_p_SskNo'] = 'Ssk Numarası';
$lang['personal_page_w_salary'] = 'Maaşı';
$lang['personal_page_w_datetime'] = 'İşe Başladığı Tarih';
$lang['personal_page_w_enddate'] = 'İşten Ayrıldığı Tarihi';
$lang['personal_page_status_'] = 'Durum';
$lang['personal_page_notes'] = 'Not';
$lang['personal_page_picture'] = 'Resim';



$lang['personal_page_i_LawCivil'] = 'Medeni Hal';
$lang['personal_page_i_city'] = 'Şehir';
$lang['personal_page_i_town'] = 'İlçe';
$lang['personal_page_i_neighborhood'] = 'Mahalle/Köy';
$lang['personal_page_firm_risk'] = 'Cild Numarası';
$lang['personal_page_i_FamilyNumber'] = 'Aile Sıra Numarası';
$lang['personal_page_i_order_no'] = 'Sıra Numarası';
$lang['personal_page_tax_verge'] = 'Kayıt No';
$lang['personal_page_i_IdentifyLocation'] = 'Verildiği Yer';
$lang['personal_page_i_whyGive'] = 'Veriliş Nedeni';
$lang['personal_page_i_GiveDate'] = 'Veriliş Tarihi';
$lang['personal_page_adress_1'] = 'Adres 1';
$lang['personal_page_adress_2'] = 'Adres 2';
$lang['personal_page_gsm_number'] = 'Cep Telefonu';
$lang['personal_page_home_number'] = 'Ev Telefonu';
$lang['personal_page_gsm_number2'] = 'Cep Telefonu';
$lang['personal_page_alternative_number'] = 'Alternatif Telefon';
$lang['personal_page_email_adress'] = 'E-mail Adresi';
$lang['personal_page_p_register_number'] = 'Sicil Numarası';
$lang['personal_page_p_SskNo'] = 'Ssk Numarası';
$lang['personal_page_w_salary'] = 'Maaşı';
$lang['personal_page_w_datetime'] = 'İşe Başladığı Tarih';
$lang['personal_page_w_enddate'] = 'İşten Ayrıldığı Tarihi';
$lang['personal_page_status_'] = 'Durum';
$lang['personal_page_notes'] = 'Not';
$lang['personal_page_picture'] = 'Resim';



$lang['company_year_of_establishment'] = 'Kuruluş yılı';
$lang['company_webpage'] = 'web sayfası';


$lang['company_holding_name'] = 'Bağlı olduğunuz holding varsa ismnini yazını';


$lang['company_company_name'] = 'Firma adı';
$lang['company_company_email'] = 'Email adresi ';



$lang['company_company_gsm'] = 'Cep numarası';
$lang['company_company_phone'] = 'Telefon Numarası';
$lang['company_company_fax'] = 'Fax Numarası';

$lang['company_center_phone'] = 'Telefon Numarası';
$lang['company_center_gsm'] = 'Cep Telefon Numarası';
$lang['center_fax'] = 'Fax Numarası';
$lang['company_center_taxVerge'] = 'Vergi dairesi';
$lang['company_center_taxNumber'] = 'Vergi Numarası';
$lang['company_tax_verge'] = 'Vergi dairesi';
$lang['company_tax_number'] = 'Vergi numarası';



$lang['company_other_phone'] = 'Telefon Numarası';
$lang['company_other_gsm'] = 'Cep Telefon Numarası';
$lang['other_fax'] = 'Fax Numarası';
$lang['company_other_taxVerge'] = 'Vergi dairesi';
$lang['company_family_member'] = 'Vergi Numarası';
$lang['company_tax_verge'] = 'Vergi dairesi';
$lang['company_tax_number'] = 'Vergi numarası';

?>